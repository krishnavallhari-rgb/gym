'use client';

import React, { useState, useEffect } from 'react';
import { usePathname } from 'next/navigation';
import Sidebar from './Sidebar';

interface AppLayoutProps {
  children: React.ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  const pathname = usePathname();
  const [transitioning, setTransitioning] = useState(false);
  const [displayKey, setDisplayKey] = useState(pathname);

  useEffect(() => {
    setTransitioning(true);
    const t = setTimeout(() => {
      setDisplayKey(pathname);
      setTransitioning(false);
    }, 120);
    return () => clearTimeout(t);
  }, [pathname]);

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-y-auto scrollbar-thin">
        <div
          key={displayKey}
          className={`min-h-full ${transitioning ? 'opacity-0' : 'page-transition'}`}
        >
          {children}
        </div>
      </main>
    </div>
  );
}