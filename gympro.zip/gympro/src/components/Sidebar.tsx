'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import AppLogo from '@/components/ui/AppLogo';
import {
  LayoutDashboard,
  Users,
  CreditCard,
  CalendarCheck,
  TrendingUp,
  Dumbbell,
  FileBarChart,
  Bell,
  Settings,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Ticket,
} from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


const navGroups = [
  {
    label: 'Core',
    items: [
      { key: 'nav-dashboard', href: '/dashboard', icon: LayoutDashboard, label: 'Dashboard', badge: null },
      { key: 'nav-members', href: '/member-management', icon: Users, label: 'Members', badge: '3' },
      { key: 'nav-plans', href: '/membership-plans', icon: Ticket, label: 'Membership Plans', badge: null },
      { key: 'nav-attendance', href: '/attendance', icon: CalendarCheck, label: 'Attendance', badge: null },
    ],
  },
  {
    label: 'Finance',
    items: [
      { key: 'nav-payments', href: '/payments', icon: CreditCard, label: 'Payments', badge: '5' },
      { key: 'nav-revenue', href: '/revenue', icon: TrendingUp, label: 'Revenue', badge: null },
    ],
  },
  {
    label: 'People',
    items: [
      { key: 'nav-trainers', href: '/trainers', icon: Dumbbell, label: 'Trainers', badge: null },
      { key: 'nav-reports', href: '/reports', icon: FileBarChart, label: 'Reports', badge: null },
    ],
  },
  {
    label: 'System',
    items: [
      { key: 'nav-notifications', href: '/notifications', icon: Bell, label: 'Notifications', badge: '7' },
      { key: 'nav-settings', href: '/settings', icon: Settings, label: 'Settings', badge: null },
    ],
  },
];

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();

  const isActive = (href: string) => pathname === href || pathname.startsWith(href + '/');

  return (
    <aside
      className={`
        relative flex flex-col h-screen bg-card border-r border-border sidebar-transition shrink-0
        ${collapsed ? 'w-16' : 'w-60'}
      `}
    >
      {/* Logo */}
      <div className={`flex items-center h-16 border-b border-border px-3 shrink-0 ${collapsed ? 'justify-center' : 'gap-2.5'}`}>
        <AppLogo size={32} />
        {!collapsed && (
          <span className="font-extrabold text-base tracking-tight text-foreground">
            Gym<span className="text-primary">Pro</span>
          </span>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto scrollbar-thin py-3 px-2 space-y-4">
        {navGroups.map((group) => (
          <div key={`group-${group.label}`}>
            {!collapsed && (
              <p className="text-[10px] font-600 uppercase tracking-widest text-muted-foreground px-2 mb-1.5">
                {group.label}
              </p>
            )}
            <ul className="space-y-0.5">
              {group.items.map((item) => {
                const active = isActive(item.href);
                const Icon = item.icon;
                return (
                  <li key={item.key}>
                    <Link
                      href={item.href}
                      title={collapsed ? item.label : undefined}
                      className={`
                        group relative flex items-center gap-3 rounded-lg px-2.5 py-2 text-sm font-500 transition-all duration-150
                        ${active
                          ? 'bg-primary/15 text-primary' :'text-muted-foreground hover:bg-muted hover:text-foreground'
                        }
                        ${collapsed ? 'justify-center' : ''}
                      `}
                    >
                      {active && (
                        <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-primary rounded-full" />
                      )}
                      <Icon size={17} className="shrink-0" />
                      {!collapsed && (
                        <span className="flex-1 truncate">{item.label}</span>
                      )}
                      {!collapsed && item.badge && (
                        <span className="ml-auto text-[10px] font-700 bg-primary/20 text-primary rounded-full px-1.5 py-0.5 leading-none">
                          {item.badge}
                        </span>
                      )}
                      {collapsed && item.badge && (
                        <span className="absolute top-0.5 right-0.5 w-2 h-2 bg-primary rounded-full" />
                      )}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      {/* Bottom user */}
      <div className="shrink-0 border-t border-border p-2 space-y-1">
        <div className={`flex items-center gap-2.5 px-2.5 py-2 rounded-lg ${collapsed ? 'justify-center' : ''}`}>
          <div className="w-7 h-7 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center shrink-0">
            <span className="text-[11px] font-700 text-primary">RK</span>
          </div>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-xs font-600 text-foreground truncate">Rahul Kumar</p>
              <p className="text-[10px] text-muted-foreground truncate">Admin</p>
            </div>
          )}
        </div>
        <button
          className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all duration-150 text-sm ${collapsed ? 'justify-center' : ''}`}
          title={collapsed ? 'Log out' : undefined}
        >
          <LogOut size={16} className="shrink-0" />
          {!collapsed && <span className="font-500">Log out</span>}
        </button>
      </div>

      {/* Collapse toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-[72px] w-6 h-6 bg-card border border-border rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:border-primary/50 transition-all duration-150 z-10"
      >
        {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
      </button>
    </aside>
  );
}