import React from 'react';

type StatusType = 'active' | 'expired' | 'pending' | 'frozen' | 'trial';

interface StatusBadgeProps {
  status: StatusType;
  size?: 'sm' | 'md';
}

const statusConfig: Record<StatusType, { label: string; className: string }> = {
  active:   { label: 'Active',          className: 'status-active' },
  expired:  { label: 'Expired',         className: 'status-expired' },
  pending:  { label: 'Pending Payment', className: 'status-pending' },
  frozen:   { label: 'Frozen',          className: 'status-frozen' },
  trial:    { label: 'Trial',           className: 'status-trial' },
};

export default function StatusBadge({ status, size = 'md' }: StatusBadgeProps) {
  const config = statusConfig[status];
  return (
    <span
      className={`
        inline-flex items-center gap-1 rounded-full font-600 leading-none
        ${config.className}
        ${size === 'sm' ? 'text-[10px] px-2 py-0.5' : 'text-xs px-2.5 py-1'}
      `}
    >
      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-80" />
      {config.label}
    </span>
  );
}