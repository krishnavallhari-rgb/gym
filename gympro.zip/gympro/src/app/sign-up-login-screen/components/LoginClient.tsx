'use client';

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { Eye, EyeOff, Dumbbell, Users, Zap, TrendingUp, Copy, CheckCircle, AlertCircle, ChevronRight } from 'lucide-react';
import AppLogo from '@/components/ui/AppLogo';
import Icon from '@/components/ui/AppIcon';


type Role = 'admin' | 'reception' | 'trainer';

interface LoginFormData {
  email: string;
  password: string;
  remember: boolean;
}

const roles: { key: Role; label: string; description: string }[] = [
  { key: 'admin',     label: 'Admin',      description: 'Full access & analytics' },
  { key: 'reception', label: 'Reception',  description: 'Members & payments' },
  { key: 'trainer',   label: 'Trainer',    description: 'Assigned members' },
];

const demoCredentials: Record<Role, { email: string; password: string }> = {
  admin:     { email: 'admin@gympro.in',     password: 'Admin@2026' },
  reception: { email: 'desk@gympro.in',      password: 'Desk@2026' },
  trainer:   { email: 'trainer@gympro.in',   password: 'Train@2026' },
};

const gymStats = [
  { icon: Users,      value: '1,240+', label: 'Active Members' },
  { icon: TrendingUp, value: '₹4.8L',  label: 'Monthly Revenue' },
  { icon: Zap,        value: '98%',    label: 'Attendance Rate' },
  { icon: Dumbbell,   value: '12',     label: 'Trainers' },
];

export default function LoginClient() {
  const router = useRouter();
  const [selectedRole, setSelectedRole] = useState<Role>('admin');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  const { register, handleSubmit, setValue, formState: { errors } } = useForm<LoginFormData>({
    defaultValues: { email: '', password: '', remember: false },
  });

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 1500);
  };

  const handleAutofill = (role: Role) => {
    const creds = demoCredentials[role];
    setValue('email', creds.email);
    setValue('password', creds.password);
    setSelectedRole(role);
    setAuthError(null);
  };

  // Backend integration point — replace with real auth API call
  const onSubmit = async (data: LoginFormData) => {
    setIsLoading(true);
    setAuthError(null);
    await new Promise((r) => setTimeout(r, 1200));

    const creds = demoCredentials[selectedRole];
    if (data.email === creds.email && data.password === creds.password) {
      router.push('/dashboard');
    } else {
      setAuthError('Invalid credentials — use the demo accounts below to sign in.');
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-1/2 xl:w-3/5 flex-col relative overflow-hidden bg-gradient-to-br from-[#0f0f0f] via-[#0a0a0a] to-[#0f0a0a]">
        {/* Background decoration */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-80 h-80 bg-accent/5 rounded-full blur-3xl translate-x-1/3 translate-y-1/3" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-primary/3 rounded-full blur-2xl" />
        </div>

        {/* Grid pattern overlay */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: 'linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)',
            backgroundSize: '40px 40px',
          }}
        />

        <div className="relative z-10 flex flex-col h-full p-10 xl:p-14">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <AppLogo size={40} />
            <span className="font-extrabold text-2xl tracking-tight text-foreground">
              Gym<span className="text-primary">Pro</span>
            </span>
          </div>

          {/* Main content */}
          <div className="flex-1 flex flex-col justify-center">
            <div className="max-w-md">
              <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-full px-3 py-1 mb-6">
                <span className="w-1.5 h-1.5 bg-accent rounded-full pulse-dot" />
                <span className="text-xs font-600 text-primary">Premium Gym Management</span>
              </div>
              <h1 className="text-4xl xl:text-5xl font-800 text-foreground leading-tight mb-4">
                Manage your gym<br />
                <span className="text-primary">like a pro.</span>
              </h1>
              <p className="text-base text-muted-foreground leading-relaxed mb-10">
                From member tracking to revenue analytics — everything your gym needs in one powerful dashboard.
              </p>

              {/* Stats grid */}
              <div className="grid grid-cols-2 gap-3">
                {gymStats.map((stat, i) => {
                  const Icon = stat.icon;
                  return (
                    <div
                      key={`stat-${i + 1}`}
                      className="glass-card rounded-xl p-4 flex items-center gap-3"
                    >
                      <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                        <Icon size={18} className="text-primary" />
                      </div>
                      <div>
                        <p className="text-lg font-700 text-foreground metric-value">{stat.value}</p>
                        <p className="text-xs text-muted-foreground">{stat.label}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <p className="text-xs text-muted-foreground">
            © 2026 GymPro. Built for fitness professionals.
          </p>
        </div>
      </div>

      {/* Right panel — Login form */}
      <div className="w-full lg:w-1/2 xl:w-2/5 flex flex-col justify-center p-6 sm:p-10 overflow-y-auto scrollbar-thin">
        <div className="w-full max-w-sm mx-auto">
          {/* Mobile logo */}
          <div className="flex items-center gap-2 mb-8 lg:hidden">
            <AppLogo size={32} />
            <span className="font-extrabold text-xl text-foreground">
              Gym<span className="text-primary">Pro</span>
            </span>
          </div>

          <h2 className="text-2xl font-700 text-foreground mb-1">Welcome back</h2>
          <p className="text-sm text-muted-foreground mb-6">Sign in to your GymPro account</p>

          {/* Role selector */}
          <div className="flex gap-1.5 p-1 bg-muted rounded-xl mb-6">
            {roles.map((role) => (
              <button
                key={`role-tab-${role.key}`}
                onClick={() => { setSelectedRole(role.key); setAuthError(null); }}
                className={`
                  flex-1 py-2 px-1 rounded-lg text-xs font-600 transition-all duration-150
                  ${selectedRole === role.key
                    ? 'bg-card text-foreground shadow-card'
                    : 'text-muted-foreground hover:text-foreground'
                  }
                `}
              >
                {role.label}
              </button>
            ))}
          </div>

          {/* Role description */}
          <div className="flex items-center gap-2 mb-6 p-3 bg-muted/50 rounded-lg border border-border">
            <div className="w-1.5 h-1.5 bg-accent rounded-full shrink-0" />
            <p className="text-xs text-muted-foreground">
              <span className="text-foreground font-600">{roles.find(r => r.key === selectedRole)?.label}:</span>{' '}
              {roles.find(r => r.key === selectedRole)?.description}
            </p>
          </div>

          {/* Auth error */}
          {authError && (
            <div className="flex items-start gap-2.5 p-3 bg-primary/10 border border-primary/20 rounded-lg mb-4 fade-in">
              <AlertCircle size={15} className="text-primary shrink-0 mt-0.5" />
              <p className="text-xs text-primary leading-relaxed">{authError}</p>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-xs font-600 text-foreground mb-1.5">
                Email Address
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                placeholder="you@gympro.in"
                className={`
                  w-full bg-input border rounded-lg px-3.5 py-2.5 text-sm text-foreground placeholder:text-muted-foreground
                  focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all duration-150
                  ${errors.email ? 'border-primary' : 'border-border'}
                `}
                {...register('email', {
                  required: 'Email is required',
                  pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Enter a valid email address' },
                })}
              />
              {errors.email && (
                <p className="mt-1 text-xs text-primary flex items-center gap-1">
                  <AlertCircle size={11} />
                  {errors.email.message}
                </p>
              )}
            </div>

            {/* Password */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label htmlFor="password" className="block text-xs font-600 text-foreground">
                  Password
                </label>
                <button type="button" className="text-xs text-primary hover:text-primary/80 transition-colors">
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  placeholder="Enter your password"
                  className={`
                    w-full bg-input border rounded-lg px-3.5 py-2.5 text-sm text-foreground placeholder:text-muted-foreground pr-10
                    focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all duration-150
                    ${errors.password ? 'border-primary' : 'border-border'}
                  `}
                  {...register('password', {
                    required: 'Password is required',
                    minLength: { value: 6, message: 'Password must be at least 6 characters' },
                  })}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
              {errors.password && (
                <p className="mt-1 text-xs text-primary flex items-center gap-1">
                  <AlertCircle size={11} />
                  {errors.password.message}
                </p>
              )}
            </div>

            {/* Remember me */}
            <div className="flex items-center gap-2">
              <input
                id="remember"
                type="checkbox"
                className="w-4 h-4 rounded border-border bg-input accent-primary cursor-pointer"
                {...register('remember')}
              />
              <label htmlFor="remember" className="text-xs text-muted-foreground cursor-pointer select-none">
                Keep me signed in for 30 days
              </label>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={isLoading}
              className={`
                w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground
                font-600 text-sm rounded-lg py-2.5 transition-all duration-150 active:scale-95
                ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}
              `}
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Signing in...</span>
                </>
              ) : (
                <>
                  <span>Sign In</span>
                  <ChevronRight size={15} />
                </>
              )}
            </button>
          </form>

          {/* Demo credentials */}
          <div className="mt-6 border border-border rounded-xl overflow-hidden">
            <div className="flex items-center gap-2 px-4 py-2.5 bg-muted/50 border-b border-border">
              <span className="text-[10px] font-700 uppercase tracking-wider text-muted-foreground">Demo Credentials</span>
            </div>
            <div className="divide-y divide-border">
              {roles.map((role) => {
                const creds = demoCredentials[role.key];
                return (
                  <div key={`demo-${role.key}`} className="px-4 py-3 flex items-center gap-3 hover:bg-muted/30 transition-colors">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-600 text-foreground mb-0.5">{role.label}</p>
                      <p className="text-[11px] text-muted-foreground truncate">{creds.email}</p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleCopy(creds.email, `${role.key}-email`)}
                        className="w-6 h-6 flex items-center justify-center rounded text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-150"
                        title="Copy email"
                      >
                        {copiedField === `${role.key}-email` ? <CheckCircle size={12} className="text-accent" /> : <Copy size={12} />}
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAutofill(role.key)}
                        className="text-[11px] font-600 text-primary hover:text-primary/80 bg-primary/10 hover:bg-primary/15 px-2 py-0.5 rounded transition-all duration-150"
                      >
                        Use
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <p className="text-center text-xs text-muted-foreground mt-6">
            By signing in, you agree to our{' '}
            <span className="text-primary cursor-pointer hover:underline">Terms of Service</span>
            {' '}and{' '}
            <span className="text-primary cursor-pointer hover:underline">Privacy Policy</span>
          </p>
        </div>
      </div>
    </div>
  );
}