'use client';

import React, { useState } from 'react';
import AppLayout from '@/components/AppLayout';
import { mockMembers } from '@/app/member-management/components/mockData';
import { FileBarChart, Download, Users, CreditCard, CalendarCheck, Clock, Search,  } from 'lucide-react';

type ReportType = 'attendance' | 'revenue' | 'expiry' | 'pending' | 'members';

interface ReportConfig {
  id: ReportType;
  label: string;
  description: string;
  icon: React.ElementType;
  color: string;
  bg: string;
}

const reportTypes: ReportConfig[] = [
  { id: 'members',    label: 'Member Report',           description: 'All member details and status',   icon: Users,         color: 'text-accent',   bg: 'bg-accent/10' },
  { id: 'attendance', label: 'Attendance Report',       description: 'Daily check-in/out records',      icon: CalendarCheck, color: 'text-[#818cf8]', bg: 'bg-indigo-500/10' },
  { id: 'revenue',    label: 'Revenue Report',          description: 'Payment collection summary',      icon: CreditCard,    color: 'text-primary',  bg: 'bg-primary/10' },
  { id: 'expiry',     label: 'Membership Expiry Report', description: 'Expiring and expired memberships', icon: Clock,        color: 'text-amber-400', bg: 'bg-amber-500/10' },
  { id: 'pending',    label: 'Pending Payment Report',  description: 'Members with outstanding dues',   icon: FileBarChart,  color: 'text-foreground', bg: 'bg-muted' },
];

const attendanceData = mockMembers.slice(0, 8).map((m, i) => ({
  name: m.name,
  memberId: m.memberId,
  date: '17/05/2026',
  status: i % 3 === 0 ? 'Absent' : i % 3 === 1 ? 'Present' : 'Checked Out',
  checkIn: i % 3 !== 0 ? `${8 + i}:${i % 2 === 0 ? '00' : '30'} AM` : '—',
}));

const expiryData = mockMembers
  .filter((m) => m.status === 'expired' || m.status === 'active')
  .slice(0, 6)
  .map((m) => ({ name: m.name, memberId: m.memberId, plan: m.plan, expiry: m.expiryDate, status: m.status }));

const pendingData = mockMembers
  .filter((m) => m.pending > 0)
  .map((m) => ({ name: m.name, memberId: m.memberId, plan: m.plan, pending: m.pending, phone: m.phone }));

export default function ReportsPage() {
  const [activeReport, setActiveReport] = useState<ReportType>('members');
  const [search, setSearch] = useState('');

  const filteredMembers = mockMembers.filter((m) => {
    const q = search.toLowerCase();
    return !q || m.name.toLowerCase().includes(q) || m.memberId.toLowerCase().includes(q);
  });

  const renderTable = () => {
    if (activeReport === 'members') {
      return (
        <table className="w-full">
          <thead>
            <tr className="border-b border-border">
              {['Member ID', 'Name', 'Phone', 'Plan', 'Joining', 'Expiry', 'Status'].map((h) => (
                <th key={h} className="text-left text-[11px] font-600 text-muted-foreground uppercase tracking-wider px-4 py-3">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filteredMembers.map((m) => (
              <tr key={m.id} className="hover:bg-muted/20 transition-colors">
                <td className="px-4 py-3 text-xs font-600 text-muted-foreground">{m.memberId}</td>
                <td className="px-4 py-3 text-sm font-600 text-foreground">{m.name}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{m.phone}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{m.plan}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{m.joiningDate}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{m.expiryDate}</td>
                <td className="px-4 py-3">
                  <span className={`text-[11px] font-600 px-2 py-0.5 rounded-full status-${m.status}`}>{m.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      );
    }
    if (activeReport === 'attendance') {
      return (
        <table className="w-full">
          <thead>
            <tr className="border-b border-border">
              {['Name', 'Member ID', 'Date', 'Status', 'Check-in Time'].map((h) => (
                <th key={h} className="text-left text-[11px] font-600 text-muted-foreground uppercase tracking-wider px-4 py-3">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {attendanceData.map((r, i) => (
              <tr key={i} className="hover:bg-muted/20 transition-colors">
                <td className="px-4 py-3 text-sm font-600 text-foreground">{r.name}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{r.memberId}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{r.date}</td>
                <td className="px-4 py-3">
                  <span className={`text-[11px] font-600 px-2 py-0.5 rounded-full ${
                    r.status === 'Present' ? 'status-active' : r.status === 'Absent' ? 'status-expired' : 'status-pending'
                  }`}>{r.status}</span>
                </td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{r.checkIn}</td>
              </tr>
            ))}
          </tbody>
        </table>
      );
    }
    if (activeReport === 'expiry') {
      return (
        <table className="w-full">
          <thead>
            <tr className="border-b border-border">
              {['Name', 'Member ID', 'Plan', 'Expiry Date', 'Status'].map((h) => (
                <th key={h} className="text-left text-[11px] font-600 text-muted-foreground uppercase tracking-wider px-4 py-3">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {expiryData.map((r, i) => (
              <tr key={i} className="hover:bg-muted/20 transition-colors">
                <td className="px-4 py-3 text-sm font-600 text-foreground">{r.name}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{r.memberId}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{r.plan}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{r.expiry}</td>
                <td className="px-4 py-3">
                  <span className={`text-[11px] font-600 px-2 py-0.5 rounded-full status-${r.status}`}>{r.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      );
    }
    if (activeReport === 'pending') {
      return (
        <table className="w-full">
          <thead>
            <tr className="border-b border-border">
              {['Name', 'Member ID', 'Plan', 'Phone', 'Pending Amount'].map((h) => (
                <th key={h} className="text-left text-[11px] font-600 text-muted-foreground uppercase tracking-wider px-4 py-3">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {pendingData.map((r, i) => (
              <tr key={i} className="hover:bg-muted/20 transition-colors">
                <td className="px-4 py-3 text-sm font-600 text-foreground">{r.name}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{r.memberId}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{r.plan}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{r.phone}</td>
                <td className="px-4 py-3 text-sm font-700 metric-value text-primary">₹{r.pending.toLocaleString('en-IN')}</td>
              </tr>
            ))}
          </tbody>
        </table>
      );
    }
    // revenue
    return (
      <div className="p-6 text-center text-sm text-muted-foreground">
        <FileBarChart size={32} className="mx-auto mb-3 opacity-30" />
        Revenue report data will be shown here
      </div>
    );
  };

  return (
    <AppLayout>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-sm border-b border-border px-6 py-4">
          <div className="max-w-screen-xl mx-auto flex items-center justify-between">
            <div>
              <h1 className="text-xl font-700 text-foreground">Reports</h1>
              <p className="text-xs text-muted-foreground mt-0.5">Generate and export gym reports</p>
            </div>
            <button className="flex items-center gap-2 bg-muted hover:bg-muted/80 border border-border text-sm font-600 text-foreground px-4 py-2 rounded-lg transition-all duration-150 active:scale-95">
              <Download size={14} />
              Export CSV
            </button>
          </div>
        </div>

        <div className="max-w-screen-xl mx-auto px-6 py-6 space-y-6">
          {/* Report type selector */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {reportTypes.map((r) => (
              <button
                key={r.id}
                onClick={() => setActiveReport(r.id)}
                className={`flex flex-col items-start gap-2 p-4 rounded-xl border transition-all duration-150 text-left ${
                  activeReport === r.id
                    ? 'border-primary/40 bg-primary/10' :'border-border bg-card hover:border-border/80 hover:bg-muted/30'
                }`}
              >
                <div className={`w-8 h-8 rounded-lg ${r.bg} flex items-center justify-center`}>
                  <r.icon size={15} className={r.color} />
                </div>
                <div>
                  <p className={`text-xs font-700 ${activeReport === r.id ? 'text-primary' : 'text-foreground'}`}>{r.label}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5 leading-relaxed">{r.description}</p>
                </div>
              </button>
            ))}
          </div>

          {/* Search */}
          {(activeReport === 'members') && (
            <div className="relative max-w-sm">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search members..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-input border border-border rounded-lg pl-9 pr-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
          )}

          {/* Table */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-border flex items-center justify-between">
              <p className="text-sm font-600 text-foreground">
                {reportTypes.find((r) => r.id === activeReport)?.label}
              </p>
              <span className="text-xs text-muted-foreground">17 May 2026</span>
            </div>
            <div className="overflow-x-auto">
              {renderTable()}
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
