'use client';

import React from 'react';
import dynamic from 'next/dynamic';

const RevenueChart = dynamic(() => import('./RevenueChart'), { ssr: false });
const AttendanceChart = dynamic(() => import('./AttendanceChart'), { ssr: false });

export default function DashboardCharts() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <RevenueChart />
      </div>
      <div>
        <AttendanceChart />
      </div>
    </div>
  );
}