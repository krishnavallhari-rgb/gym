'use client';

import React from 'react';
import { UserPlus, CreditCard, CalendarCheck, RefreshCw, UserX, Dumbbell } from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


type ActivityType = 'check-in' | 'payment' | 'registration' | 'renewal' | 'freeze' | 'trainer';

interface Activity {
  id: string;
  type: ActivityType;
  title: string;
  subtitle: string;
  time: string;
  amount?: string;
}

const activities: Activity[] = [
  { id: 'act-001', type: 'check-in',     title: 'Priya Nair checked in',          subtitle: 'Gate 1 · Batch Morning',        time: '6:28 AM' },
  { id: 'act-002', type: 'payment',      title: 'Payment received — Vikram Patel', subtitle: 'Monthly Plan · UPI',            time: '6:15 AM', amount: '₹1,800' },
  { id: 'act-003', type: 'registration', title: 'New member — Meera Iyer',        subtitle: 'Annual Plan · Trainer: Suresh', time: '5:55 AM' },
  { id: 'act-004', type: 'renewal',      title: 'Membership renewed — Karan M.',  subtitle: 'Quarterly Plan · Cash',         time: '5:40 AM', amount: '₹4,500' },
  { id: 'act-005', type: 'check-in',     title: 'Rohit Gupta checked in',         subtitle: 'Gate 2 · Batch Early',          time: '5:30 AM' },
  { id: 'act-006', type: 'trainer',      title: 'Suresh Kumar marked attendance', subtitle: 'Trainer · 6 AM batch',          time: '5:20 AM' },
  { id: 'act-007', type: 'freeze',       title: 'Membership frozen — Ananya S.',  subtitle: 'Medical leave · 30 days',       time: '5:00 AM' },
  { id: 'act-008', type: 'payment',      title: 'Partial payment — Arjun Sharma', subtitle: 'Monthly Plan · Cash',           time: '4:45 AM', amount: '₹900' },
];

const activityConfig: Record<ActivityType, { icon: React.ElementType; bgClass: string; iconClass: string }> = {
  'check-in':     { icon: CalendarCheck, bgClass: 'bg-accent/10',   iconClass: 'text-accent' },
  'payment':      { icon: CreditCard,    bgClass: 'bg-primary/10',  iconClass: 'text-primary' },
  'registration': { icon: UserPlus,      bgClass: 'bg-sky-500/10',  iconClass: 'text-sky-400' },
  'renewal':      { icon: RefreshCw,     bgClass: 'bg-accent/10',   iconClass: 'text-accent' },
  'freeze':       { icon: UserX,         bgClass: 'bg-indigo-500/10', iconClass: 'text-indigo-400' },
  'trainer':      { icon: Dumbbell,      bgClass: 'bg-muted',       iconClass: 'text-muted-foreground' },
};

export default function RecentActivityFeed() {
  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="flex items-center justify-between px-5 py-4 border-b border-border">
        <h3 className="text-sm font-700 text-foreground">Recent Activity</h3>
        <button className="text-xs text-primary hover:text-primary/80 font-600 transition-colors">
          View all
        </button>
      </div>
      <div className="divide-y divide-border">
        {activities.map((activity) => {
          const config = activityConfig[activity.type];
          const Icon = config.icon;
          return (
            <div
              key={activity.id}
              className="flex items-start gap-3 px-5 py-3 hover:bg-muted/20 transition-colors"
            >
              <div className={`w-8 h-8 rounded-lg ${config.bgClass} flex items-center justify-center shrink-0 mt-0.5`}>
                <Icon size={14} className={config.iconClass} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-500 text-foreground leading-snug">{activity.title}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{activity.subtitle}</p>
              </div>
              <div className="shrink-0 text-right">
                <p className="text-xs text-muted-foreground">{activity.time}</p>
                {activity.amount && (
                  <p className="text-xs font-700 text-accent mt-0.5 metric-value">{activity.amount}</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}