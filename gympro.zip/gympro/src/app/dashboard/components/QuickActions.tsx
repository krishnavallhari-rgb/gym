'use client';

import React, { useState } from 'react';
import { UserPlus, CreditCard, CalendarCheck, ChevronDown } from 'lucide-react';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';


const actions = [
  { key: 'qa-add-member',    label: 'Add Member',      icon: UserPlus,      href: '/member-management' },
  { key: 'qa-record-pay',    label: 'Record Payment',  icon: CreditCard,    href: '/payments' },
  { key: 'qa-checkin',       label: 'Check-in Member', icon: CalendarCheck, href: '/attendance' },
];

export default function QuickActions() {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 bg-primary hover:bg-primary/90 text-primary-foreground text-xs font-600 px-3 py-1.5 rounded-lg transition-all duration-150 active:scale-95"
      >
        Quick Actions
        <ChevronDown size={13} className={`transition-transform duration-200 ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-1.5 w-44 bg-card border border-border rounded-xl shadow-elevated z-30 fade-in overflow-hidden">
          {actions?.map((action) => {
            const Icon = action?.icon;
            return (
              <Link
                key={action?.key}
                href={action?.href}
                onClick={() => setOpen(false)}
                className="flex items-center gap-2.5 px-3.5 py-2.5 text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-150"
              >
                <Icon size={15} className="text-primary" />
                {action?.label}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}