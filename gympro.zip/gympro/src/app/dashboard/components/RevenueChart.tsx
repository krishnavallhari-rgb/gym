'use client';

import React from 'react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer,
} from 'recharts';

const revenueData = [
  { month: 'Jun',  revenue: 312000, collections: 298000 },
  { month: 'Jul',  revenue: 341000, collections: 315000 },
  { month: 'Aug',  revenue: 389000, collections: 372000 },
  { month: 'Sep',  revenue: 356000, collections: 340000 },
  { month: 'Oct',  revenue: 402000, collections: 388000 },
  { month: 'Nov',  revenue: 378000, collections: 361000 },
  { month: 'Dec',  revenue: 445000, collections: 429000 },
  { month: 'Jan',  revenue: 421000, collections: 405000 },
  { month: 'Feb',  revenue: 398000, collections: 381000 },
  { month: 'Mar',  revenue: 467000, collections: 443000 },
  { month: 'Apr',  revenue: 431000, collections: 412000 },
  { month: 'May',  revenue: 483200, collections: 452000 },
];

const formatINR = (val: number) => `₹${(val / 1000).toFixed(0)}K`;

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: { value: number; name: string }[]; label?: string }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg px-3 py-2.5 shadow-elevated">
      <p className="text-xs font-600 text-foreground mb-1.5">{label} 2026</p>
      {payload.map((p, i) => (
        <div key={`tooltip-item-${i + 1}`} className="flex items-center gap-2 text-xs">
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: i === 0 ? 'var(--primary)' : 'var(--accent)' }} />
          <span className="text-muted-foreground capitalize">{p.name}:</span>
          <span className="font-600 text-foreground">₹{p.value.toLocaleString('en-IN')}</span>
        </div>
      ))}
    </div>
  );
};

export default function RevenueChart() {
  return (
    <div className="bg-card border border-border rounded-xl p-5 h-full">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="text-sm font-700 text-foreground">Monthly Revenue</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Jun 2025 – May 2026</p>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-primary" />
            <span className="text-muted-foreground">Billed</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-accent" />
            <span className="text-muted-foreground">Collected</span>
          </div>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={220}>
        <AreaChart data={revenueData} margin={{ top: 4, right: 4, left: -10, bottom: 0 }}>
          <defs>
            <linearGradient id="revGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.3} />
              <stop offset="95%" stopColor="var(--primary)" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="colGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="var(--accent)" stopOpacity={0.2} />
              <stop offset="95%" stopColor="var(--accent)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
          <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
          <YAxis tickFormatter={formatINR} tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
          <Tooltip content={<CustomTooltip />} />
          <Area type="monotone" dataKey="revenue" name="revenue" stroke="var(--primary)" strokeWidth={2} fill="url(#revGradient)" />
          <Area type="monotone" dataKey="collections" name="collected" stroke="var(--accent)" strokeWidth={2} fill="url(#colGradient)" />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}