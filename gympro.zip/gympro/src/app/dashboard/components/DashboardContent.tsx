import React from 'react';
import KPIBentoGrid from './KPIBentoGrid';
import DashboardCharts from './DashboardCharts';
import ExpiringMembersList from './ExpiringMembersList';
import RecentActivityFeed from './RecentActivityFeed';
import QuickActions from './QuickActions';

export default function DashboardContent() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-sm border-b border-border px-6 py-4">
        <div className="max-w-screen-2xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-xl font-700 text-foreground">Dashboard</h1>
            <p className="text-xs text-muted-foreground mt-0.5">Sunday, 17 May 2026 — Good morning, Rahul</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 bg-accent/10 border border-accent/20 rounded-lg px-3 py-1.5">
              <span className="w-1.5 h-1.5 bg-accent rounded-full pulse-dot" />
              <span className="text-xs font-600 text-accent">Live</span>
            </div>
            <QuickActions />
          </div>
        </div>
      </div>

      <div className="max-w-screen-2xl mx-auto px-6 py-6 space-y-6">
        <KPIBentoGrid />
        <DashboardCharts />
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          <ExpiringMembersList />
          <RecentActivityFeed />
        </div>
      </div>
    </div>
  );
}