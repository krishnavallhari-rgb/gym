'use client';

import React from 'react';
import { Users, UserCheck, AlertTriangle, TrendingUp, TrendingDown, IndianRupee, UserPlus, Clock,  } from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


interface KPICard {
  id: string;
  label: string;
  value: string;
  subValue?: string;
  trend?: { value: string; positive: boolean };
  icon: React.ElementType;
  variant: 'default' | 'positive' | 'negative' | 'warning' | 'info';
  span?: 'normal' | 'wide';
}

const kpiCards: KPICard[] = [
  {
    id: 'kpi-active-members',
    label: 'Active Members',
    value: '1,247',
    subValue: '94% of total',
    trend: { value: '+23 this month', positive: true },
    icon: UserCheck,
    variant: 'positive',
    span: 'wide',
  },
  {
    id: 'kpi-monthly-revenue',
    label: 'Monthly Revenue',
    value: '₹4,83,200',
    subValue: 'May 2026',
    trend: { value: '+12.4% vs Apr', positive: true },
    icon: IndianRupee,
    variant: 'default',
    span: 'wide',
  },
  {
    id: 'kpi-checkins',
    label: "Today's Check-ins",
    value: '184',
    subValue: 'as of 6:32 AM',
    trend: { value: '+18 vs yesterday', positive: true },
    icon: UserCheck,
    variant: 'info',
  },
  {
    id: 'kpi-expiring',
    label: 'Expiring This Week',
    value: '34',
    subValue: 'need renewal',
    trend: { value: '8 expire today', positive: false },
    icon: AlertTriangle,
    variant: 'warning',
  },
  {
    id: 'kpi-pending',
    label: 'Pending Payments',
    value: '₹68,400',
    subValue: 'from 21 members',
    trend: { value: '+₹4,200 overdue', positive: false },
    icon: IndianRupee,
    variant: 'negative',
  },
  {
    id: 'kpi-new-reg',
    label: 'New Registrations',
    value: '47',
    subValue: 'this month',
    trend: { value: '+9 vs last month', positive: true },
    icon: UserPlus,
    variant: 'positive',
  },
  {
    id: 'kpi-total-members',
    label: 'Total Members',
    value: '1,326',
    subValue: 'all time',
    trend: { value: '+47 this month', positive: true },
    icon: Users,
    variant: 'default',
  },
  {
    id: 'kpi-avg-attendance',
    label: 'Avg Daily Attendance',
    value: '178',
    subValue: 'last 30 days',
    trend: { value: '-6 vs prev month', positive: false },
    icon: Clock,
    variant: 'default',
  },
];

const variantStyles: Record<KPICard['variant'], {
  bg: string; border: string; iconBg: string; iconColor: string; trendColor: string;
}> = {
  default:  { bg: 'bg-card',          border: 'border-border',          iconBg: 'bg-muted',          iconColor: 'text-muted-foreground', trendColor: 'text-muted-foreground' },
  positive: { bg: 'bg-card',          border: 'border-accent/20',       iconBg: 'bg-accent/10',      iconColor: 'text-accent',           trendColor: 'text-accent' },
  negative: { bg: 'bg-primary/5',     border: 'border-primary/20',      iconBg: 'bg-primary/10',     iconColor: 'text-primary',          trendColor: 'text-primary' },
  warning:  { bg: 'bg-yellow-500/5',  border: 'border-yellow-500/20',   iconBg: 'bg-yellow-500/10',  iconColor: 'text-yellow-500',       trendColor: 'text-yellow-500' },
  info:     { bg: 'bg-sky-500/5',     border: 'border-sky-500/20',      iconBg: 'bg-sky-500/10',     iconColor: 'text-sky-400',          trendColor: 'text-sky-400' },
};

export default function KPIBentoGrid() {
  return (
    // 8 cards: row1 = hero(2 wide) + hero(2 wide) = 4 cols; row2 = 4 normal
    <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-4 2xl:grid-cols-4 gap-4">
      {kpiCards.map((card) => {
        const styles = variantStyles[card.variant];
        const Icon = card.icon;
        const TrendIcon = card.trend?.positive ? TrendingUp : TrendingDown;

        return (
          <div
            key={card.id}
            className={`
              ${styles.bg} border ${styles.border} rounded-xl p-4 glass-card-hover
              ${card.span === 'wide' ? 'md:col-span-2' : ''}
            `}
          >
            <div className="flex items-start justify-between mb-3">
              <div className={`w-9 h-9 rounded-lg ${styles.iconBg} flex items-center justify-center`}>
                <Icon size={18} className={styles.iconColor} />
              </div>
              {card.trend && (
                <div className={`flex items-center gap-1 text-[11px] font-600 ${styles.trendColor}`}>
                  <TrendIcon size={11} />
                  <span>{card.trend.value}</span>
                </div>
              )}
            </div>
            <p className="text-[11px] font-600 uppercase tracking-wider text-muted-foreground mb-1">{card.label}</p>
            <p className="text-2xl font-800 text-foreground metric-value leading-none mb-1">{card.value}</p>
            {card.subValue && (
              <p className="text-xs text-muted-foreground">{card.subValue}</p>
            )}
          </div>
        );
      })}
    </div>
  );
}