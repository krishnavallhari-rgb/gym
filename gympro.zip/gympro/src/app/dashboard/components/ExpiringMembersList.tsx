'use client';

import React from 'react';
import { AlertTriangle, RefreshCw, Phone } from 'lucide-react';
import StatusBadge from '@/components/ui/StatusBadge';

const expiringMembers = [
  { id: 'mem-001', name: 'Arjun Sharma',    plan: 'Monthly',    expiry: '17 May',  daysLeft: 0,  phone: '98765-43210', status: 'expired' as const },
  { id: 'mem-002', name: 'Priya Nair',      plan: 'Quarterly',  expiry: '18 May',  daysLeft: 1,  phone: '87654-32109', status: 'active' as const },
  { id: 'mem-003', name: 'Vikram Patel',    plan: 'Monthly',    expiry: '19 May',  daysLeft: 2,  phone: '76543-21098', status: 'active' as const },
  { id: 'mem-004', name: 'Sneha Reddy',     plan: 'Half-Yearly', expiry: '20 May', daysLeft: 3,  phone: '65432-10987', status: 'active' as const },
  { id: 'mem-005', name: 'Karan Mehta',     plan: 'Monthly',    expiry: '21 May',  daysLeft: 4,  phone: '54321-09876', status: 'pending' as const },
  { id: 'mem-006', name: 'Ananya Singh',    plan: 'Annual',     expiry: '22 May',  daysLeft: 5,  phone: '43210-98765', status: 'active' as const },
  { id: 'mem-007', name: 'Rohit Gupta',     plan: 'Monthly',    expiry: '23 May',  daysLeft: 6,  phone: '32109-87654', status: 'active' as const },
];

export default function ExpiringMembersList() {
  return (
    <div className="bg-card border border-yellow-500/20 rounded-xl overflow-hidden">
      <div className="flex items-center justify-between px-5 py-4 border-b border-border bg-yellow-500/5">
        <div className="flex items-center gap-2">
          <AlertTriangle size={16} className="text-yellow-500" />
          <h3 className="text-sm font-700 text-foreground">Expiring This Week</h3>
          <span className="text-[11px] font-700 bg-yellow-500/15 text-yellow-500 border border-yellow-500/25 rounded-full px-2 py-0.5">
            {expiringMembers.length}
          </span>
        </div>
        <button className="text-xs text-primary hover:text-primary/80 font-600 transition-colors">
          View all
        </button>
      </div>
      <div className="divide-y divide-border">
        {expiringMembers.map((member) => (
          <div
            key={member.id}
            className="flex items-center gap-3 px-5 py-3 hover:bg-muted/30 transition-colors group"
          >
            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0">
              <span className="text-[11px] font-700 text-muted-foreground">
                {member.name.split(' ').map(n => n[0]).join('')}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="text-sm font-600 text-foreground truncate">{member.name}</p>
                {member.daysLeft === 0 && (
                  <span className="text-[10px] font-700 text-primary bg-primary/10 px-1.5 py-0.5 rounded">TODAY</span>
                )}
              </div>
              <p className="text-xs text-muted-foreground">{member.plan} · Expires {member.expiry}</p>
            </div>
            <div className="flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
              <button
                className="w-7 h-7 flex items-center justify-center rounded-lg bg-muted hover:bg-muted/80 text-muted-foreground hover:text-foreground transition-all duration-150"
                title="Call member"
              >
                <Phone size={13} />
              </button>
              <button
                className="w-7 h-7 flex items-center justify-center rounded-lg bg-accent/10 hover:bg-accent/20 text-accent transition-all duration-150"
                title="Renew membership"
              >
                <RefreshCw size={13} />
              </button>
            </div>
            <div className="shrink-0 ml-1">
              <StatusBadge status={member.status} size="sm" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}