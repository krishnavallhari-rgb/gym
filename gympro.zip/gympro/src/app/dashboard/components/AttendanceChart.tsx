'use client';

import React from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Cell,
} from 'recharts';

const attendanceData = [
  { day: 'Mon', count: 203, isToday: false },
  { day: 'Tue', count: 187, isToday: false },
  { day: 'Wed', count: 224, isToday: false },
  { day: 'Thu', count: 196, isToday: false },
  { day: 'Fri', count: 241, isToday: false },
  { day: 'Sat', count: 312, isToday: false },
  { day: 'Sun', count: 184, isToday: true },
];

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg px-3 py-2 shadow-elevated">
      <p className="text-xs font-600 text-foreground">{label}</p>
      <p className="text-xs text-accent font-700">{payload[0].value} check-ins</p>
    </div>
  );
};

export default function AttendanceChart() {
  return (
    <div className="bg-card border border-border rounded-xl p-5 h-full">
      <div className="mb-5">
        <h3 className="text-sm font-700 text-foreground">This Week's Attendance</h3>
        <p className="text-xs text-muted-foreground mt-0.5">Daily check-ins — Week of 11–17 May</p>
      </div>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={attendanceData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
          <XAxis dataKey="day" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
          <Tooltip content={<CustomTooltip />} />
          <Bar dataKey="count" radius={[4, 4, 0, 0]}>
            {attendanceData.map((entry, index) => (
              <Cell
                key={`bar-cell-${entry.day}`}
                fill={entry.isToday ? 'var(--primary)' : 'var(--accent)'}
                opacity={entry.isToday ? 1 : 0.6}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
        <div className="text-center">
          <p className="text-xs text-muted-foreground">Today</p>
          <p className="text-sm font-700 text-primary metric-value">184</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-muted-foreground">Week Avg</p>
          <p className="text-sm font-700 text-foreground metric-value">221</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-muted-foreground">Week Peak</p>
          <p className="text-sm font-700 text-accent metric-value">312</p>
        </div>
      </div>
    </div>
  );
}