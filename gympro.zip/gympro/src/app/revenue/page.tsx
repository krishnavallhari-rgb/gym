'use client';

import React, { useState } from 'react';
import AppLayout from '@/components/AppLayout';
import { TrendingUp, IndianRupee, Clock, CheckCircle2, ArrowUpRight, ArrowDownRight,  } from 'lucide-react';
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell,  } from 'recharts';

const monthlyRevenue = [
  { month: 'Nov', revenue: 82000, target: 90000 },
  { month: 'Dec', revenue: 95000, target: 90000 },
  { month: 'Jan', revenue: 88000, target: 95000 },
  { month: 'Feb', revenue: 102000, target: 95000 },
  { month: 'Mar', revenue: 115000, target: 100000 },
  { month: 'Apr', revenue: 98000, target: 100000 },
  { month: 'May', revenue: 124000, target: 110000 },
];

const planRevenue = [
  { plan: 'Monthly', revenue: 28800, members: 16 },
  { plan: 'Quarterly', revenue: 36000, members: 8 },
  { plan: 'Half-Yearly', revenue: 34000, members: 4 },
  { plan: 'Annual', revenue: 54000, members: 3 },
  { plan: 'Personal', revenue: 24000, members: 2 },
];

const paymentModes = [
  { name: 'UPI', value: 52, color: '#22c55e' },
  { name: 'Cash', value: 28, color: '#ef4444' },
  { name: 'Card', value: 12, color: '#818cf8' },
  { name: 'Bank', value: 8, color: '#f59e0b' },
];

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number; name: string; color: string }>; label?: string }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded-lg px-3 py-2.5 shadow-lg">
        <p className="text-xs font-600 text-muted-foreground mb-1">{label}</p>
        {payload.map((p, i) => (
          <p key={i} className="text-xs font-700" style={{ color: p.color }}>
            {p.name}: ₹{Number(p.value).toLocaleString('en-IN')}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function RevenuePage() {
  const [period, setPeriod] = useState<'week' | 'month' | 'year'>('month');

  const kpis = [
    { label: 'Total Revenue', value: '₹7,04,000', change: '+12.4%', up: true, icon: IndianRupee, color: 'text-accent', bg: 'bg-accent/10' },
    { label: 'Monthly Revenue', value: '₹1,24,000', change: '+26.5%', up: true, icon: TrendingUp, color: 'text-primary', bg: 'bg-primary/10' },
    { label: 'Pending Revenue', value: '₹2,900', change: '-8.2%', up: false, icon: Clock, color: 'text-amber-400', bg: 'bg-amber-500/10' },
    { label: 'Daily Collection', value: '₹4,800', change: '+5.1%', up: true, icon: CheckCircle2, color: 'text-[#818cf8]', bg: 'bg-indigo-500/10' },
  ];

  return (
    <AppLayout>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-sm border-b border-border px-6 py-4">
          <div className="max-w-screen-xl mx-auto flex items-center justify-between">
            <div>
              <h1 className="text-xl font-700 text-foreground">Revenue & Analytics</h1>
              <p className="text-xs text-muted-foreground mt-0.5">Financial overview and trends</p>
            </div>
            <div className="flex items-center gap-1 bg-muted/50 border border-border rounded-lg p-1">
              {(['week', 'month', 'year'] as const).map((p) => (
                <button
                  key={p}
                  onClick={() => setPeriod(p)}
                  className={`px-3 py-1.5 rounded-md text-xs font-600 transition-all duration-150 capitalize ${
                    period === p ? 'bg-primary text-white' : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="max-w-screen-xl mx-auto px-6 py-6 space-y-6">
          {/* KPI cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {kpis.map((k) => (
              <div key={k.label} className="bg-card border border-border rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-9 h-9 rounded-lg ${k.bg} flex items-center justify-center`}>
                    <k.icon size={16} className={k.color} />
                  </div>
                  <span className={`flex items-center gap-0.5 text-xs font-600 ${k.up ? 'text-accent' : 'text-primary'}`}>
                    {k.up ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                    {k.change}
                  </span>
                </div>
                <p className="text-xl font-800 metric-value text-foreground">{k.value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{k.label}</p>
              </div>
            ))}
          </div>

          {/* Revenue trend chart */}
          <div className="bg-card border border-border rounded-xl p-5">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-sm font-700 text-foreground">Revenue Trend</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Monthly revenue vs target</p>
              </div>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-primary rounded-full inline-block" />Revenue</span>
                <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-border rounded-full inline-block" />Target</span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={240}>
              <AreaChart data={monthlyRevenue} margin={{ top: 5, right: 5, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#2a2a2a" />
                <XAxis dataKey="month" tick={{ fill: '#737373', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#737373', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="revenue" name="Revenue" stroke="#ef4444" strokeWidth={2} fill="url(#revGrad)" />
                <Area type="monotone" dataKey="target" name="Target" stroke="#2a2a2a" strokeWidth={1.5} fill="none" strokeDasharray="4 4" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Plan revenue + Payment modes */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Plan-wise revenue */}
            <div className="lg:col-span-2 bg-card border border-border rounded-xl p-5">
              <div className="mb-5">
                <h3 className="text-sm font-700 text-foreground">Plan-wise Revenue</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Revenue breakdown by membership plan</p>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={planRevenue} margin={{ top: 0, right: 5, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2a2a2a" vertical={false} />
                  <XAxis dataKey="plan" tick={{ fill: '#737373', fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#737373', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                  <Tooltip
                    contentStyle={{ background: '#111', border: '1px solid #2a2a2a', borderRadius: '8px' }}
                    labelStyle={{ color: '#737373', fontSize: 11 }}
                    itemStyle={{ color: '#ef4444', fontSize: 11 }}
                    formatter={(v: number) => [`₹${v.toLocaleString('en-IN')}`, 'Revenue']}
                  />
                  <Bar dataKey="revenue" fill="#ef4444" radius={[4, 4, 0, 0]} opacity={0.85} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Payment modes pie */}
            <div className="bg-card border border-border rounded-xl p-5">
              <div className="mb-4">
                <h3 className="text-sm font-700 text-foreground">Payment Modes</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Collection by method</p>
              </div>
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie data={paymentModes} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={3} dataKey="value">
                    {paymentModes.map((entry, i) => (
                      <Cell key={`cell-${i}`} fill={entry.color} opacity={0.85} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: '#111', border: '1px solid #2a2a2a', borderRadius: '8px' }}
                    formatter={(v: number) => [`${v}%`, '']}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-1.5 mt-2">
                {paymentModes.map((m) => (
                  <div key={m.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ background: m.color }} />
                      <span className="text-muted-foreground">{m.name}</span>
                    </div>
                    <span className="font-600 text-foreground">{m.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
