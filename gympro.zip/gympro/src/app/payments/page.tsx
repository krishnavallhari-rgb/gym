'use client';

import React, { useState } from 'react';
import AppLayout from '@/components/AppLayout';
import { mockMembers } from '@/app/member-management/components/mockData';
import {
  CreditCard, Search, Plus, IndianRupee, Clock, CheckCircle2,
  X, Check,
} from 'lucide-react';

type PaymentMode = 'Cash' | 'UPI' | 'Bank Transfer' | 'Card';
type PaymentStatus = 'paid' | 'pending' | 'partial';

interface Payment {
  id: string;
  paymentId: string;
  memberId: string;
  memberName: string;
  memberCode: string;
  date: string;
  amount: number;
  mode: PaymentMode;
  status: PaymentStatus;
  notes: string;
}

const mockPayments: Payment[] = [
  { id: 'p1', paymentId: 'PAY-001', memberId: 'mem-002', memberName: 'Priya Nair', memberCode: 'GP-1002', date: '17/05/2026', amount: 4300, mode: 'UPI', status: 'paid', notes: 'Quarterly renewal' },
  { id: 'p2', paymentId: 'PAY-002', memberId: 'mem-003', memberName: 'Vikram Patel', memberCode: 'GP-1003', date: '16/05/2026', amount: 8000, mode: 'Cash', status: 'partial', notes: '₹500 pending' },
  { id: 'p3', paymentId: 'PAY-003', memberId: 'mem-004', memberName: 'Sneha Reddy', memberCode: 'GP-1004', date: '15/05/2026', amount: 8500, mode: 'UPI', status: 'paid', notes: 'Half-yearly plan' },
  { id: 'p4', paymentId: 'PAY-004', memberId: 'mem-005', memberName: 'Karan Mehta', memberCode: 'GP-1005', date: '14/05/2026', amount: 900, mode: 'Cash', status: 'partial', notes: '₹900 pending' },
  { id: 'p5', paymentId: 'PAY-005', memberId: 'mem-007', memberName: 'Rohit Gupta', memberCode: 'GP-1007', date: '13/05/2026', amount: 16000, mode: 'Bank Transfer', status: 'paid', notes: 'Annual plan' },
  { id: 'p6', paymentId: 'PAY-006', memberId: 'mem-008', memberName: 'Meera Iyer', memberCode: 'GP-1008', date: '17/05/2026', amount: 500, mode: 'UPI', status: 'paid', notes: 'Trial plan' },
  { id: 'p7', paymentId: 'PAY-007', memberId: 'mem-010', memberName: 'Pooja Krishnamurthy', memberCode: 'GP-1010', date: '12/05/2026', amount: 16500, mode: 'Card', status: 'paid', notes: 'Annual plan' },
  { id: 'p8', paymentId: 'PAY-008', memberId: 'mem-011', memberName: 'Nikhil Joshi', memberCode: 'GP-1011', date: '11/05/2026', amount: 3000, mode: 'UPI', status: 'partial', notes: '₹1,500 pending' },
  { id: 'p9', paymentId: 'PAY-009', memberId: 'mem-012', memberName: 'Divya Menon', memberCode: 'GP-1012', date: '10/05/2026', amount: 12000, mode: 'Bank Transfer', status: 'paid', notes: 'Personal training' },
];

const statusConfig: Record<PaymentStatus, { label: string; color: string; bg: string; border: string }> = {
  paid:    { label: 'Paid',    color: 'text-accent',    bg: 'bg-accent/10',    border: 'border-accent/25' },
  pending: { label: 'Pending', color: 'text-primary',   bg: 'bg-primary/10',   border: 'border-primary/25' },
  partial: { label: 'Partial', color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/25' },
};

const modeColorMap: Record<PaymentMode, string> = {
  'UPI':           'text-accent',
  'Cash':          'text-amber-400',
  'Card':          'text-[#818cf8]',
  'Bank Transfer': 'text-[#38bdf8]',
};

interface RecordPaymentModalProps {
  onClose: () => void;
  onSave: (p: Payment) => void;
}

function RecordPaymentModal({ onClose, onSave }: RecordPaymentModalProps) {
  const [memberId, setMemberId] = useState('');
  const [amount, setAmount] = useState('');
  const [mode, setMode] = useState<PaymentMode>('UPI');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  const selectedMember = mockMembers.find((m) => m.id === memberId);

  const handleSave = async () => {
    if (!memberId || !amount) return;
    setSaving(true);
    await new Promise((r) => setTimeout(r, 700));
    const newPayment: Payment = {
      id: `p-new-${Date.now()}`,
      paymentId: `PAY-${Math.floor(Math.random() * 900) + 100}`,
      memberId,
      memberName: selectedMember?.name ?? '',
      memberCode: selectedMember?.memberId ?? '',
      date: new Date().toLocaleDateString('en-GB').replace(/\//g, '/'),
      amount: Number(amount),
      mode,
      status: 'paid',
      notes,
    };
    onSave(newPayment);
    setSaving(false);
    onClose();
  };

  const inputCls = 'w-full bg-input border border-border rounded-lg px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-card border border-border rounded-2xl w-full max-w-md shadow-2xl fade-in">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <h3 className="text-base font-700 text-foreground">Record Payment</h3>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted">
            <X size={15} />
          </button>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-600 text-foreground mb-1.5">Select Member <span className="text-primary">*</span></label>
            <select value={memberId} onChange={(e) => setMemberId(e.target.value)} className={inputCls + ' appearance-none cursor-pointer'}>
              <option value="">Choose a member...</option>
              {mockMembers.map((m) => (
                <option key={m.id} value={m.id}>{m.name} ({m.memberId})</option>
              ))}
            </select>
          </div>
          {selectedMember && (
            <div className="bg-muted/40 border border-border rounded-lg px-3 py-2.5 text-xs">
              <p className="text-muted-foreground">Plan: <span className="text-foreground font-600">{selectedMember.plan}</span></p>
              {selectedMember.pending > 0 && (
                <p className="text-primary font-600 mt-0.5">Pending: ₹{selectedMember.pending.toLocaleString('en-IN')}</p>
              )}
            </div>
          )}
          <div>
            <label className="block text-xs font-600 text-foreground mb-1.5">Amount (₹) <span className="text-primary">*</span></label>
            <input
              type="number"
              min={0}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount"
              className={inputCls}
            />
          </div>
          <div>
            <label className="block text-xs font-600 text-foreground mb-1.5">Payment Mode</label>
            <select value={mode} onChange={(e) => setMode(e.target.value as PaymentMode)} className={inputCls + ' appearance-none cursor-pointer'}>
              {(['Cash', 'UPI', 'Bank Transfer', 'Card'] as PaymentMode[]).map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-600 text-foreground mb-1.5">Notes</label>
            <input type="text" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Optional notes..." className={inputCls} />
          </div>
        </div>
        <div className="flex items-center gap-2 px-5 py-4 border-t border-border">
          <button onClick={onClose} className="flex-1 py-2 rounded-lg border border-border text-sm font-600 text-muted-foreground hover:text-foreground hover:bg-muted transition-all">Cancel</button>
          <button
            onClick={handleSave}
            disabled={!memberId || !amount || saving}
            className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg bg-accent hover:bg-accent/90 text-white text-sm font-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Check size={14} />}
            {saving ? 'Saving...' : 'Save Payment'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function PaymentsPage() {
  const [payments, setPayments] = useState<Payment[]>(mockPayments);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | PaymentStatus>('all');
  const [showModal, setShowModal] = useState(false);

  const filtered = payments.filter((p) => {
    const q = search.toLowerCase();
    const matchSearch = !q || p.memberName.toLowerCase().includes(q) || p.paymentId.toLowerCase().includes(q) || p.memberCode.toLowerCase().includes(q);
    const matchStatus = filterStatus === 'all' || p.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const totalCollected = payments.filter((p) => p.status === 'paid').reduce((s, p) => s + p.amount, 0);
  const totalPending = mockMembers.reduce((s, m) => s + m.pending, 0);
  const todayCollection = payments.filter((p) => p.date === '17/05/2026').reduce((s, p) => s + p.amount, 0);

  return (
    <AppLayout>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-sm border-b border-border px-6 py-4">
          <div className="max-w-screen-xl mx-auto flex items-center justify-between">
            <div>
              <h1 className="text-xl font-700 text-foreground">Payments</h1>
              <p className="text-xs text-muted-foreground mt-0.5">Fee collection and payment history</p>
            </div>
            <button
              onClick={() => setShowModal(true)}
              className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-white text-sm font-600 px-4 py-2 rounded-lg transition-all duration-150 active:scale-95"
            >
              <Plus size={15} />
              Record Payment
            </button>
          </div>
        </div>

        <div className="max-w-screen-xl mx-auto px-6 py-6 space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { label: 'Total Collected', value: `₹${totalCollected.toLocaleString('en-IN')}`, icon: CheckCircle2, color: 'text-accent', bg: 'bg-accent/10' },
              { label: 'Pending Revenue', value: `₹${totalPending.toLocaleString('en-IN')}`, icon: Clock, color: 'text-primary', bg: 'bg-primary/10' },
              { label: "Today's Collection", value: `₹${todayCollection.toLocaleString('en-IN')}`, icon: IndianRupee, color: 'text-[#818cf8]', bg: 'bg-indigo-500/10' },
            ].map((s) => (
              <div key={s.label} className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg ${s.bg} flex items-center justify-center`}>
                  <s.icon size={18} className={s.color} />
                </div>
                <div>
                  <p className="text-xl font-800 metric-value text-foreground">{s.value}</p>
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Search + Filter */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search by member name, ID, or payment ID..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-input border border-border rounded-lg pl-9 pr-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <div className="flex gap-2">
              {(['all', 'paid', 'partial', 'pending'] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilterStatus(f)}
                  className={`px-3 py-2 rounded-lg text-xs font-600 border transition-all duration-150 capitalize ${
                    filterStatus === f
                      ? 'bg-primary/15 text-primary border-primary/30' :'bg-muted/50 text-muted-foreground border-border hover:text-foreground'
                  }`}
                >
                  {f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Payments table */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-border">
              <p className="text-sm font-600 text-foreground">{filtered.length} payment{filtered.length !== 1 ? 's' : ''}</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    {['Payment ID', 'Member', 'Date', 'Amount', 'Mode', 'Status', 'Notes'].map((h) => (
                      <th key={h} className="text-left text-[11px] font-600 text-muted-foreground uppercase tracking-wider px-4 py-3">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-12 text-sm text-muted-foreground">
                        <CreditCard size={28} className="mx-auto mb-2 opacity-30" />
                        No payments found
                      </td>
                    </tr>
                  ) : (
                    filtered.map((p) => {
                      const cfg = statusConfig[p.status];
                      return (
                        <tr key={p.id} className="hover:bg-muted/20 transition-colors">
                          <td className="px-4 py-3 text-xs font-600 text-muted-foreground">{p.paymentId}</td>
                          <td className="px-4 py-3">
                            <p className="text-sm font-600 text-foreground">{p.memberName}</p>
                            <p className="text-[10px] text-muted-foreground">{p.memberCode}</p>
                          </td>
                          <td className="px-4 py-3 text-xs text-muted-foreground">{p.date}</td>
                          <td className="px-4 py-3 text-sm font-700 metric-value text-foreground">₹{p.amount.toLocaleString('en-IN')}</td>
                          <td className={`px-4 py-3 text-xs font-600 ${modeColorMap[p.mode]}`}>{p.mode}</td>
                          <td className="px-4 py-3">
                            <span className={`text-[11px] font-600 px-2.5 py-1 rounded-full border ${cfg.color} ${cfg.bg} ${cfg.border}`}>{cfg.label}</span>
                          </td>
                          <td className="px-4 py-3 text-xs text-muted-foreground">{p.notes || '—'}</td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {showModal && (
        <RecordPaymentModal
          onClose={() => setShowModal(false)}
          onSave={(p) => setPayments((prev) => [p, ...prev])}
        />
      )}
    </AppLayout>
  );
}
