'use client';

import React, { useState, useMemo } from 'react';
import AppLayout from '@/components/AppLayout';
import { mockMembers } from '@/app/member-management/components/mockData';
import type { Member } from '@/app/member-management/components/mockData';
import {
  Search, UserCheck, UserX, Clock, CheckCircle2, XCircle,
  Calendar, Users, TrendingUp, RefreshCw,
} from 'lucide-react';

type AttendanceStatus = 'present' | 'absent' | 'checked-out';

interface AttendanceRecord {
  memberId: string;
  status: AttendanceStatus;
  checkInTime: string | null;
  checkOutTime: string | null;
}

const today = new Date();
const todayStr = today.toLocaleDateString('en-IN', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });

function formatTime(date: Date) {
  return date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
}

function AttendanceSkeleton() {
  return (
    <div className="space-y-3 p-4">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={`att-skel-${i}`} className="skeleton-shimmer h-16 rounded-xl" />
      ))}
    </div>
  );
}

const statusConfig: Record<AttendanceStatus, { label: string; color: string; bg: string; border: string }> = {
  present:     { label: 'Present',      color: 'text-accent',   bg: 'bg-accent/10',   border: 'border-accent/25' },
  absent:      { label: 'Absent',       color: 'text-primary',  bg: 'bg-primary/10',  border: 'border-primary/25' },
  'checked-out': { label: 'Checked Out', color: 'text-[#f59e0b]', bg: 'bg-amber-500/10', border: 'border-amber-500/25' },
};

export default function AttendancePage() {
  const [search, setSearch] = useState('');
  const [attendance, setAttendance] = useState<Record<string, AttendanceRecord>>({});
  const [loading, setLoading] = useState(false);
  const [filterStatus, setFilterStatus] = useState<'all' | AttendanceStatus>('all');

  const activeMembers = useMemo(
    () => mockMembers.filter((m) => m.status === 'active' || m.status === 'trial'),
    []
  );

  const filtered = useMemo(() => {
    let list = activeMembers;
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (m) => m.name.toLowerCase().includes(q) || m.memberId.toLowerCase().includes(q) || m.phone.includes(q)
      );
    }
    if (filterStatus !== 'all') {
      list = list.filter((m) => {
        const rec = attendance[m.id];
        const st = rec?.status ?? 'absent';
        return st === filterStatus;
      });
    }
    return list;
  }, [activeMembers, search, filterStatus, attendance]);

  const stats = useMemo(() => {
    const present = Object.values(attendance).filter((r) => r.status === 'present').length;
    const checkedOut = Object.values(attendance).filter((r) => r.status === 'checked-out').length;
    const total = activeMembers.length;
    return { present, checkedOut, absent: total - present - checkedOut, total };
  }, [attendance, activeMembers]);

  const simulateLoad = (fn: () => void) => {
    setLoading(true);
    setTimeout(() => { fn(); setLoading(false); }, 600);
  };

  const handleCheckIn = (member: Member) => {
    simulateLoad(() => {
      setAttendance((prev) => ({
        ...prev,
        [member.id]: {
          memberId: member.id,
          status: 'present',
          checkInTime: formatTime(new Date()),
          checkOutTime: null,
        },
      }));
    });
  };

  const handleCheckOut = (member: Member) => {
    simulateLoad(() => {
      setAttendance((prev) => ({
        ...prev,
        [member.id]: {
          ...prev[member.id],
          status: 'checked-out',
          checkOutTime: formatTime(new Date()),
        },
      }));
    });
  };

  const handleToggleStatus = (member: Member) => {
    const rec = attendance[member.id];
    if (!rec || rec.status === 'absent') {
      handleCheckIn(member);
    } else if (rec.status === 'present') {
      handleCheckOut(member);
    } else {
      // checked-out → mark absent (undo)
      simulateLoad(() => {
        setAttendance((prev) => {
          const next = { ...prev };
          delete next[member.id];
          return next;
        });
      });
    }
  };

  const getMemberStatus = (memberId: string): AttendanceStatus => {
    return attendance[memberId]?.status ?? 'absent';
  };

  return (
    <AppLayout>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-sm border-b border-border px-6 py-4">
          <div className="max-w-screen-xl mx-auto flex items-center justify-between">
            <div>
              <h1 className="text-xl font-700 text-foreground">Attendance</h1>
              <p className="text-xs text-muted-foreground mt-0.5">{todayStr}</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 bg-accent/10 border border-accent/20 rounded-lg px-3 py-1.5">
                <span className="w-1.5 h-1.5 bg-accent rounded-full pulse-dot" />
                <span className="text-xs font-600 text-accent">Live</span>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-screen-xl mx-auto px-6 py-6 space-y-6">
          {/* Stats row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Total Active', value: stats.total, icon: Users, color: 'text-foreground', bg: 'bg-muted/50' },
              { label: 'Present Today', value: stats.present, icon: CheckCircle2, color: 'text-accent', bg: 'bg-accent/10' },
              { label: 'Checked Out', value: stats.checkedOut, icon: Clock, color: 'text-amber-400', bg: 'bg-amber-500/10' },
              { label: 'Absent', value: stats.absent, icon: XCircle, color: 'text-primary', bg: 'bg-primary/10' },
            ].map((s) => (
              <div key={s.label} className={`${s.bg} border border-border rounded-xl p-4 flex items-center gap-3`}>
                <div className={`w-10 h-10 rounded-lg ${s.bg} border border-border flex items-center justify-center`}>
                  <s.icon size={18} className={s.color} />
                </div>
                <div>
                  <p className="text-2xl font-800 metric-value text-foreground">{s.value}</p>
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Search + Filter */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search by name, ID, or phone..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-input border border-border rounded-lg pl-9 pr-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <div className="flex gap-2">
              {(['all', 'present', 'checked-out', 'absent'] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilterStatus(f)}
                  className={`px-3 py-2 rounded-lg text-xs font-600 border transition-all duration-150 capitalize ${
                    filterStatus === f
                      ? 'bg-primary/15 text-primary border-primary/30' :'bg-muted/50 text-muted-foreground border-border hover:text-foreground'
                  }`}
                >
                  {f === 'all' ? 'All' : f === 'checked-out' ? 'Checked Out' : f.charAt(0).toUpperCase() + f.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Member list */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-border flex items-center justify-between">
              <p className="text-sm font-600 text-foreground">
                {filtered.length} member{filtered.length !== 1 ? 's' : ''}
                {search ? ` matching "${search}"` : ''}
              </p>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <TrendingUp size={12} />
                <span>{stats.present > 0 ? Math.round((stats.present / stats.total) * 100) : 0}% attendance rate</span>
              </div>
            </div>

            {loading ? (
              <AttendanceSkeleton />
            ) : filtered.length === 0 ? (
              <div className="py-16 text-center">
                <Users size={32} className="mx-auto text-muted-foreground mb-3 opacity-40" />
                <p className="text-sm text-muted-foreground">No members found</p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {filtered.map((member) => {
                  const status = getMemberStatus(member.id);
                  const rec = attendance[member.id];
                  const cfg = statusConfig[status];

                  return (
                    <div
                      key={member.id}
                      className="flex items-center gap-4 px-4 py-3.5 hover:bg-muted/30 transition-colors duration-150"
                    >
                      {/* Avatar */}
                      <div className="w-9 h-9 rounded-full bg-primary/15 border border-primary/25 flex items-center justify-center shrink-0">
                        <span className="text-xs font-700 text-primary">
                          {member.name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase()}
                        </span>
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-600 text-foreground truncate">{member.name}</p>
                          <span className="text-[10px] text-muted-foreground font-500 shrink-0">{member.memberId}</span>
                        </div>
                        <div className="flex items-center gap-3 mt-0.5">
                          <p className="text-xs text-muted-foreground">{member.plan}</p>
                          {rec?.checkInTime && (
                            <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                              <Clock size={9} />
                              In: {rec.checkInTime}
                            </span>
                          )}
                          {rec?.checkOutTime && (
                            <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                              <Clock size={9} />
                              Out: {rec.checkOutTime}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Status badge */}
                      <span className={`text-[11px] font-600 px-2.5 py-1 rounded-full border ${cfg.color} ${cfg.bg} ${cfg.border} shrink-0`}>
                        {cfg.label}
                      </span>

                      {/* Action buttons */}
                      <div className="flex items-center gap-2 shrink-0">
                        {status === 'absent' && (
                          <button
                            onClick={() => handleCheckIn(member)}
                            className="flex items-center gap-1.5 bg-accent/15 hover:bg-accent/25 text-accent border border-accent/25 text-xs font-600 px-3 py-1.5 rounded-lg transition-all duration-150 active:scale-95"
                          >
                            <UserCheck size={13} />
                            Check In
                          </button>
                        )}
                        {status === 'present' && (
                          <button
                            onClick={() => handleCheckOut(member)}
                            className="flex items-center gap-1.5 bg-amber-500/15 hover:bg-amber-500/25 text-amber-400 border border-amber-500/25 text-xs font-600 px-3 py-1.5 rounded-lg transition-all duration-150 active:scale-95"
                          >
                            <UserX size={13} />
                            Check Out
                          </button>
                        )}
                        {status === 'checked-out' && (
                          <button
                            onClick={() => handleToggleStatus(member)}
                            className="flex items-center gap-1.5 bg-muted hover:bg-muted/80 text-muted-foreground border border-border text-xs font-600 px-3 py-1.5 rounded-lg transition-all duration-150 active:scale-95"
                          >
                            <RefreshCw size={13} />
                            Undo
                          </button>
                        )}
                        {/* Toggle status button */}
                        <button
                          onClick={() => handleToggleStatus(member)}
                          title="Toggle attendance status"
                          className={`w-8 h-8 rounded-lg border flex items-center justify-center transition-all duration-150 active:scale-95 ${
                            status === 'present' ?'bg-accent/10 border-accent/25 text-accent hover:bg-accent/20'
                              : status === 'checked-out' ?'bg-amber-500/10 border-amber-500/25 text-amber-400 hover:bg-amber-500/20' :'bg-muted border-border text-muted-foreground hover:text-foreground hover:bg-muted/80'
                          }`}
                        >
                          <Calendar size={13} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
