'use client';

import React, { useState } from 'react';
import AppLayout from '@/components/AppLayout';
import {
  Bell, AlertTriangle, RefreshCw, UserPlus, CreditCard,
  CheckCircle2, Clock, X, Filter,
} from 'lucide-react';

interface Notification {
  id: string;
  type: 'expiry' | 'payment' | 'renewal' | 'registration' | 'alert';
  title: string;
  message: string;
  time: string;
  read: boolean;
  member?: string;
}

const mockNotifications: Notification[] = [
  { id: 'n1', type: 'expiry', title: 'Membership Expiring Soon', message: 'Arjun Sharma\'s membership expires in 3 days (GP-1001)', time: '2 min ago', read: false, member: 'Arjun Sharma' },
  { id: 'n2', type: 'payment', title: 'Pending Payment Alert', message: 'Vikram Patel has ₹500 pending dues (GP-1003)', time: '15 min ago', read: false, member: 'Vikram Patel' },
  { id: 'n3', type: 'payment', title: 'Pending Payment Alert', message: 'Karan Mehta has ₹900 pending dues (GP-1005)', time: '32 min ago', read: false, member: 'Karan Mehta' },
  { id: 'n4', type: 'renewal', title: 'Renewal Reminder', message: 'Aditya Verma\'s membership expired on 30/04/2026 — follow up for renewal', time: '1 hr ago', read: false, member: 'Aditya Verma' },
  { id: 'n5', type: 'registration', title: 'New Member Registered', message: 'Meera Iyer joined as a Trial member (GP-1008)', time: '2 hrs ago', read: true, member: 'Meera Iyer' },
  { id: 'n6', type: 'payment', title: 'Pending Payment Alert', message: 'Nikhil Joshi has ₹1,500 pending dues (GP-1011)', time: '3 hrs ago', read: true, member: 'Nikhil Joshi' },
  { id: 'n7', type: 'expiry', title: 'Membership Expiring Soon', message: 'Priya Nair\'s membership expires in 1 day (GP-1002)', time: '4 hrs ago', read: true, member: 'Priya Nair' },
  { id: 'n8', type: 'alert', title: 'System Alert', message: 'Daily attendance report generated for 17 May 2026', time: '6 hrs ago', read: true },
  { id: 'n9', type: 'renewal', title: 'Renewal Reminder', message: 'Ananya Singh\'s membership is frozen — check status (GP-1006)', time: '8 hrs ago', read: true, member: 'Ananya Singh' },
  { id: 'n10', type: 'registration', title: 'New Member Registered', message: 'Divya Menon enrolled in Personal Training plan (GP-1012)', time: '1 day ago', read: true, member: 'Divya Menon' },
];

const typeConfig = {
  expiry:       { icon: Clock,         color: 'text-amber-400',  bg: 'bg-amber-500/10',  border: 'border-amber-500/20',  label: 'Expiry' },
  payment:      { icon: CreditCard,    color: 'text-primary',    bg: 'bg-primary/10',    border: 'border-primary/20',    label: 'Payment' },
  renewal:      { icon: RefreshCw,     color: 'text-[#818cf8]',  bg: 'bg-indigo-500/10', border: 'border-indigo-500/20', label: 'Renewal' },
  registration: { icon: UserPlus,      color: 'text-accent',     bg: 'bg-accent/10',     border: 'border-accent/20',     label: 'New Member' },
  alert:        { icon: AlertTriangle, color: 'text-foreground', bg: 'bg-muted',         border: 'border-border',        label: 'System' },
};

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const unreadCount = notifications.filter((n) => !n.read).length;

  const markAllRead = () => setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  const markRead = (id: string) => setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, read: true } : n));
  const dismiss = (id: string) => setNotifications((prev) => prev.filter((n) => n.id !== id));

  const displayed = filter === 'unread' ? notifications.filter((n) => !n.read) : notifications;

  return (
    <AppLayout>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-sm border-b border-border px-6 py-4">
          <div className="max-w-screen-lg mx-auto flex items-center justify-between">
            <div>
              <h1 className="text-xl font-700 text-foreground">Notifications</h1>
              <p className="text-xs text-muted-foreground mt-0.5">
                {unreadCount > 0 ? `${unreadCount} unread alert${unreadCount !== 1 ? 's' : ''}` : 'All caught up'}
              </p>
            </div>
            <div className="flex items-center gap-2">
              {unreadCount > 0 && (
                <button
                  onClick={markAllRead}
                  className="flex items-center gap-1.5 text-xs font-600 text-muted-foreground hover:text-foreground bg-muted/50 hover:bg-muted border border-border px-3 py-1.5 rounded-lg transition-all duration-150"
                >
                  <CheckCircle2 size={13} />
                  Mark all read
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="max-w-screen-lg mx-auto px-6 py-6 space-y-5">
          {/* Filter tabs */}
          <div className="flex items-center gap-2">
            <Filter size={14} className="text-muted-foreground" />
            {(['all', 'unread'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1.5 rounded-lg text-xs font-600 border transition-all duration-150 ${
                  filter === f
                    ? 'bg-primary/15 text-primary border-primary/30' :'bg-muted/50 text-muted-foreground border-border hover:text-foreground'
                }`}
              >
                {f === 'all' ? `All (${notifications.length})` : `Unread (${unreadCount})`}
              </button>
            ))}
          </div>

          {/* Notification list */}
          <div className="space-y-2">
            {displayed.length === 0 ? (
              <div className="bg-card border border-border rounded-xl py-16 text-center">
                <Bell size={32} className="mx-auto text-muted-foreground mb-3 opacity-40" />
                <p className="text-sm text-muted-foreground">No notifications</p>
              </div>
            ) : (
              displayed.map((n) => {
                const cfg = typeConfig[n.type];
                const IconComp = cfg.icon;
                return (
                  <div
                    key={n.id}
                    onClick={() => markRead(n.id)}
                    className={`group relative flex items-start gap-4 bg-card border rounded-xl px-4 py-4 cursor-pointer transition-all duration-150 hover:border-border/80 ${
                      !n.read ? 'border-border/60 bg-card' : 'border-border/30 opacity-70 hover:opacity-100'
                    }`}
                  >
                    {!n.read && (
                      <span className="absolute top-4 right-10 w-2 h-2 bg-primary rounded-full" />
                    )}
                    <div className={`w-9 h-9 rounded-lg ${cfg.bg} border ${cfg.border} flex items-center justify-center shrink-0 mt-0.5`}>
                      <IconComp size={16} className={cfg.color} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <p className={`text-sm font-600 ${!n.read ? 'text-foreground' : 'text-muted-foreground'}`}>{n.title}</p>
                        <span className={`text-[10px] font-600 px-1.5 py-0.5 rounded-full border ${cfg.color} ${cfg.bg} ${cfg.border}`}>
                          {cfg.label}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed">{n.message}</p>
                      <p className="text-[10px] text-muted-foreground mt-1.5">{n.time}</p>
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); dismiss(n.id); }}
                      className="opacity-0 group-hover:opacity-100 w-6 h-6 flex items-center justify-center rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-150 shrink-0"
                    >
                      <X size={12} />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
