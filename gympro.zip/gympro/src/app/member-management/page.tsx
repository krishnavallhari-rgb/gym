import React from 'react';
import AppLayout from '@/components/AppLayout';
import MemberManagementContent from './components/MemberManagementContent';

export default function MemberManagementPage() {
  return (
    <AppLayout>
      <MemberManagementContent />
    </AppLayout>
  );
}