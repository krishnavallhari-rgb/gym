'use client';

import React, { useState, useMemo } from 'react';
import { Plus, Download, Filter, X } from 'lucide-react';
import { mockMembers, type Member, type MemberStatus, type MembershipPlan } from './mockData';
import MemberTable from './MemberTable';
import AddMemberSlideOver from './AddMemberSlideOver';
import MemberFilters from './MemberFilters';

export default function MemberManagementContent() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All Status');
  const [planFilter, setPlanFilter] = useState<string>('All Plans');
  const [trainerFilter, setTrainerFilter] = useState<string>('All Trainers');
  const [showFilters, setShowFilters] = useState(false);
  const [showAddMember, setShowAddMember] = useState(false);
  const [members, setMembers] = useState<Member[]>(mockMembers);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const filteredMembers = useMemo(() => {
    return members.filter((m) => {
      const matchSearch =
        !search ||
        m.name.toLowerCase().includes(search.toLowerCase()) ||
        m.phone.includes(search) ||
        m.memberId.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === 'All Status' || m.status === statusFilter;
      const matchPlan = planFilter === 'All Plans' || m.plan === planFilter;
      const matchTrainer = trainerFilter === 'All Trainers' || m.trainer === trainerFilter;
      return matchSearch && matchStatus && matchPlan && matchTrainer;
    });
  }, [members, search, statusFilter, planFilter, trainerFilter]);

  const activeFilterCount = [
    statusFilter !== 'All Status',
    planFilter !== 'All Plans',
    trainerFilter !== 'All Trainers',
  ].filter(Boolean).length;

  const handleDeleteMember = (id: string) => {
    setMembers((prev) => prev.filter((m) => m.id !== id));
    setSelectedIds((prev) => prev.filter((sid) => sid !== id));
  };

  const handleBulkDelete = () => {
    setMembers((prev) => prev.filter((m) => !selectedIds.includes(m.id)));
    setSelectedIds([]);
  };

  const clearFilters = () => {
    setStatusFilter('All Status');
    setPlanFilter('All Plans');
    setTrainerFilter('All Trainers');
    setSearch('');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-sm border-b border-border px-6 py-4">
        <div className="max-w-screen-2xl mx-auto flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
          <div>
            <h1 className="text-xl font-700 text-foreground">Members</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {filteredMembers.length} of {members.length} members shown
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button
              className="flex items-center gap-1.5 text-xs font-600 text-muted-foreground hover:text-foreground bg-muted hover:bg-muted/80 px-3 py-1.5 rounded-lg transition-all duration-150"
            >
              <Download size={14} />
              Export
            </button>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`
                relative flex items-center gap-1.5 text-xs font-600 px-3 py-1.5 rounded-lg transition-all duration-150
                ${showFilters || activeFilterCount > 0
                  ? 'bg-primary/15 text-primary border border-primary/20' :'text-muted-foreground hover:text-foreground bg-muted hover:bg-muted/80'
                }
              `}
            >
              <Filter size={14} />
              Filters
              {activeFilterCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-primary text-primary-foreground text-[9px] font-700 rounded-full flex items-center justify-center">
                  {activeFilterCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setShowAddMember(true)}
              className="flex items-center gap-1.5 bg-primary hover:bg-primary/90 text-primary-foreground text-xs font-600 px-3 py-1.5 rounded-lg transition-all duration-150 active:scale-95"
            >
              <Plus size={14} />
              Add Member
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-screen-2xl mx-auto px-6 py-4 space-y-4">
        {/* Search */}
        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-sm">
            <input
              type="text"
              placeholder="Search by name, phone, or member ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-input border border-border rounded-lg pl-9 pr-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all duration-150"
            />
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            {search && (
              <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
                <X size={14} />
              </button>
            )}
          </div>
          {activeFilterCount > 0 && (
            <button
              onClick={clearFilters}
              className="text-xs text-muted-foreground hover:text-primary flex items-center gap-1 transition-colors"
            >
              <X size={12} />
              Clear filters
            </button>
          )}
        </div>

        {/* Filters panel */}
        {showFilters && (
          <MemberFilters
            statusFilter={statusFilter}
            planFilter={planFilter}
            trainerFilter={trainerFilter}
            onStatusChange={setStatusFilter}
            onPlanChange={setPlanFilter}
            onTrainerChange={setTrainerFilter}
          />
        )}

        {/* Bulk action bar */}
        {selectedIds.length > 0 && (
          <div className="flex items-center gap-3 bg-primary/10 border border-primary/20 rounded-xl px-4 py-2.5 fade-in">
            <span className="text-sm font-600 text-primary">{selectedIds.length} selected</span>
            <div className="h-4 w-px bg-border" />
            <button
              onClick={handleBulkDelete}
              className="text-xs font-600 text-primary hover:text-primary/80 transition-colors"
            >
              Delete selected
            </button>
            <button
              onClick={() => setSelectedIds([])}
              className="ml-auto text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors"
            >
              <X size={12} />
              Clear selection
            </button>
          </div>
        )}

        {/* Table */}
        <MemberTable
          members={filteredMembers}
          selectedIds={selectedIds}
          onSelectIds={setSelectedIds}
          onDelete={handleDeleteMember}
          totalCount={members.length}
        />
      </div>

      {/* Add Member Slide-over */}
      <AddMemberSlideOver
        open={showAddMember}
        onClose={() => setShowAddMember(false)}
        onAdd={(member) => {
          // Backend integration point — POST /api/members
          setMembers((prev) => [member, ...prev]);
          setShowAddMember(false);
        }}
      />
    </div>
  );
}