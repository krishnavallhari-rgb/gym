'use client';

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { X, AlertCircle, Check, ChevronRight, ChevronLeft } from 'lucide-react';
import { type Member, type MemberStatus, type MembershipPlan } from './mockData';
import { toast } from 'sonner';

interface AddMemberSlideOverProps {
  open: boolean;
  onClose: () => void;
  onAdd: (member: Member) => void;
}

interface MemberFormData {
  name: string;
  phone: string;
  email: string;
  gender: 'Male' | 'Female' | 'Other';
  dob: string;
  address: string;
  emergencyContact: string;
  joiningDate: string;
  plan: MembershipPlan;
  trainer: string;
  fees: number;
  discount: number;
  paid: number;
  height: string;
  weight: string;
  fitnessGoal: string;
  medicalNotes: string;
}

const steps = [
  { id: 'step-personal',     label: 'Personal Info' },
  { id: 'step-membership',   label: 'Membership' },
  { id: 'step-health',       label: 'Health & Goals' },
];

const InputField = ({
  id, label, helper, error, required, children,
}: {
  id: string; label: string; helper?: string; error?: string; required?: boolean; children: React.ReactNode;
}) => (
  <div>
    <label htmlFor={id} className="block text-xs font-600 text-foreground mb-1.5">
      {label}{required && <span className="text-primary ml-0.5">*</span>}
    </label>
    {helper && <p className="text-[11px] text-muted-foreground mb-1.5">{helper}</p>}
    {children}
    {error && (
      <p className="mt-1 text-xs text-primary flex items-center gap-1">
        <AlertCircle size={11} />
        {error}
      </p>
    )}
  </div>
);

const inputClass = (hasError: boolean) => `
  w-full bg-input border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground
  focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all duration-150
  ${hasError ? 'border-primary' : 'border-border'}
`;

export default function AddMemberSlideOver({ open, onClose, onAdd }: AddMemberSlideOverProps) {
  const [step, setStep] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register, handleSubmit, watch, reset, trigger,
    formState: { errors },
  } = useForm<MemberFormData>({
    defaultValues: {
      gender: 'Male',
      joiningDate: new Date().toLocaleDateString('en-GB').replace(/\//g, '/'),
      plan: 'Monthly',
      trainer: 'Suresh Kumar',
      discount: 0,
      paid: 0,
    },
  });

  const feesValue = watch('fees') || 0;
  const discountValue = watch('discount') || 0;
  const paidValue = watch('paid') || 0;
  const pendingAmount = Math.max(0, Number(feesValue) - Number(discountValue) - Number(paidValue));

  const step1Fields: (keyof MemberFormData)[] = ['name', 'phone', 'email', 'gender', 'dob', 'address', 'emergencyContact'];
  const step2Fields: (keyof MemberFormData)[] = ['joiningDate', 'plan', 'trainer', 'fees', 'discount', 'paid'];

  const handleNext = async () => {
    const fieldsToValidate = step === 0 ? step1Fields : step2Fields;
    const valid = await trigger(fieldsToValidate);
    if (valid) setStep(step + 1);
  };

  // Backend integration point — POST /api/members with form data
  const onSubmit = async (data: MemberFormData) => {
    setIsSubmitting(true);
    await new Promise((r) => setTimeout(r, 1000));
    const idNum = Math.floor(Math.random() * 900) + 100;
    const newMember: Member = {
      id: `mem-new-${idNum}`,
      memberId: `GP-${1300 + idNum}`,
      name: data.name,
      phone: data.phone,
      email: data.email,
      gender: data.gender,
      dob: data.dob,
      address: data.address,
      emergencyContact: data.emergencyContact,
      joiningDate: data.joiningDate,
      expiryDate: '17/06/2026',
      plan: data.plan,
      trainer: data.trainer,
      fees: Number(data.fees),
      discount: Number(data.discount),
      paid: Number(data.paid),
      pending: pendingAmount,
      status: pendingAmount > 0 ? 'pending' : 'active',
      height: data.height,
      weight: data.weight,
      fitnessGoal: data.fitnessGoal,
      medicalNotes: data.medicalNotes || 'None',
      checkinsThisMonth: 0,
    };
    onAdd(newMember);
    toast.success(`${data.name} added successfully as ${newMember.memberId}`);
    reset();
    setStep(0);
    setIsSubmitting(false);
  };

  const handleClose = () => {
    onClose();
    setTimeout(() => { reset(); setStep(0); }, 300);
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={handleClose} />
      <div className="relative w-full max-w-md bg-card border-l border-border h-full flex flex-col shadow-modal slide-in-right">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0">
          <div>
            <h2 className="text-base font-700 text-foreground">Add New Member</h2>
            <p className="text-xs text-muted-foreground mt-0.5">Step {step + 1} of {steps.length}</p>
          </div>
          <button
            onClick={handleClose}
            className="w-8 h-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-150"
            aria-label="Close panel"
          >
            <X size={16} />
          </button>
        </div>

        {/* Step indicator */}
        <div className="flex items-center gap-0 px-6 py-3 border-b border-border shrink-0">
          {steps.map((s, i) => (
            <React.Fragment key={s.id}>
              <div className="flex items-center gap-2">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-700 transition-all duration-200 ${
                  i < step ? 'bg-accent text-white' :
                  i === step ? 'bg-primary text-white': 'bg-muted text-muted-foreground'
                }`}>
                  {i < step ? <Check size={11} /> : i + 1}
                </div>
                <span className={`text-xs font-600 hidden sm:block ${i === step ? 'text-foreground' : 'text-muted-foreground'}`}>
                  {s.label}
                </span>
              </div>
              {i < steps.length - 1 && (
                <div className={`flex-1 h-px mx-2 transition-all duration-200 ${i < step ? 'bg-accent' : 'bg-border'}`} />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Form body */}
        <form onSubmit={handleSubmit(onSubmit)} className="flex-1 overflow-y-auto scrollbar-thin">
          <div className="px-6 py-5 space-y-4">

            {/* Step 1: Personal Info */}
            {step === 0 && (
              <>
                <InputField id="name" label="Full Name" required error={errors.name?.message}>
                  <input
                    id="name"
                    type="text"
                    placeholder="e.g. Arjun Sharma"
                    className={inputClass(!!errors.name)}
                    {...register('name', { required: 'Full name is required' })}
                  />
                </InputField>

                <div className="grid grid-cols-2 gap-3">
                  <InputField id="phone" label="Mobile Number" required error={errors.phone?.message}>
                    <input
                      id="phone"
                      type="tel"
                      placeholder="9876543210"
                      maxLength={10}
                      className={inputClass(!!errors.phone)}
                      {...register('phone', {
                        required: 'Mobile number is required',
                        pattern: { value: /^[0-9]{10}$/, message: 'Enter a valid 10-digit mobile number' },
                        onChange: (e) => {
                          e.target.value = e.target.value.replace(/\D/g, '').slice(0, 10);
                        },
                      })}
                    />
                  </InputField>
                  <InputField id="gender" label="Gender" required>
                    <select
                      id="gender"
                      className={inputClass(false) + ' appearance-none cursor-pointer'}
                      {...register('gender')}
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </InputField>
                </div>

                <InputField id="email" label="Email Address" error={errors.email?.message}>
                  <input
                    id="email"
                    type="email"
                    placeholder="arjun@gmail.com"
                    className={inputClass(!!errors.email)}
                    {...register('email', {
                      pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Enter a valid email address' },
                    })}
                  />
                </InputField>

                <InputField id="dob" label="Date of Birth" helper="Format: DD/MM/YYYY" error={errors.dob?.message}>
                  <input
                    id="dob"
                    type="text"
                    placeholder="15/03/1992"
                    className={inputClass(!!errors.dob)}
                    {...register('dob')}
                  />
                </InputField>

                <InputField id="address" label="Address" error={errors.address?.message}>
                  <textarea
                    id="address"
                    rows={2}
                    placeholder="42 MG Road, Bengaluru"
                    className={inputClass(false) + ' resize-none'}
                    {...register('address')}
                  />
                </InputField>

                <InputField id="emergencyContact" label="Emergency Contact" helper="Mobile number of a family member or friend">
                  <input
                    id="emergencyContact"
                    type="tel"
                    placeholder="98765-00001"
                    className={inputClass(false)}
                    {...register('emergencyContact')}
                  />
                </InputField>
              </>
            )}

            {/* Step 2: Membership */}
            {step === 1 && (
              <>
                <InputField id="joiningDate" label="Joining Date" required helper="Format: DD/MM/YYYY" error={errors.joiningDate?.message}>
                  <input
                    id="joiningDate"
                    type="text"
                    placeholder="17/05/2026"
                    className={inputClass(!!errors.joiningDate)}
                    {...register('joiningDate', { required: 'Joining date is required' })}
                  />
                </InputField>

                <InputField id="plan" label="Membership Plan" required>
                  <select
                    id="plan"
                    className={inputClass(false) + ' appearance-none cursor-pointer'}
                    {...register('plan', { required: true })}
                  >
                    <option value="Monthly">Monthly — ₹1,800</option>
                    <option value="Quarterly">Quarterly — ₹4,500</option>
                    <option value="Half-Yearly">Half-Yearly — ₹8,500</option>
                    <option value="Annual">Annual — ₹18,000</option>
                    <option value="Personal Training">Personal Training — ₹12,000</option>
                    <option value="Trial">Trial — ₹500</option>
                  </select>
                </InputField>

                <InputField id="trainer" label="Assign Trainer" required>
                  <select
                    id="trainer"
                    className={inputClass(false) + ' appearance-none cursor-pointer'}
                    {...register('trainer', { required: true })}
                  >
                    <option value="Suresh Kumar">Suresh Kumar</option>
                    <option value="Kavita Rao">Kavita Rao</option>
                    <option value="Rajan Pillai">Rajan Pillai</option>
                  </select>
                </InputField>

                <div className="grid grid-cols-2 gap-3">
                  <InputField id="fees" label="Total Fees (₹)" required error={errors.fees?.message}>
                    <input
                      id="fees"
                      type="number"
                      placeholder="1800"
                      min={0}
                      className={inputClass(!!errors.fees)}
                      {...register('fees', {
                        required: 'Fees amount is required',
                        min: { value: 0, message: 'Must be ≥ 0' },
                      })}
                    />
                  </InputField>
                  <InputField id="discount" label="Discount (₹)" helper="Optional">
                    <input
                      id="discount"
                      type="number"
                      placeholder="0"
                      min={0}
                      className={inputClass(false)}
                      {...register('discount', { min: 0 })}
                    />
                  </InputField>
                </div>

                <InputField id="paid" label="Amount Paid (₹)" required error={errors.paid?.message} helper="Enter amount collected today">
                  <input
                    id="paid"
                    type="number"
                    placeholder="1800"
                    min={0}
                    className={inputClass(!!errors.paid)}
                    {...register('paid', {
                      required: 'Paid amount is required',
                      min: { value: 0, message: 'Must be ≥ 0' },
                    })}
                  />
                </InputField>

                {/* Auto-calculated pending */}
                <div className="bg-muted/50 border border-border rounded-lg px-4 py-3 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-600 text-muted-foreground">Pending Amount</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Auto-calculated: Fees − Discount − Paid</p>
                  </div>
                  <p className={`text-lg font-800 metric-value ${pendingAmount > 0 ? 'text-primary' : 'text-accent'}`}>
                    ₹{pendingAmount.toLocaleString('en-IN')}
                  </p>
                </div>
              </>
            )}

            {/* Step 3: Health & Goals */}
            {step === 2 && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <InputField id="height" label="Height" helper={`e.g. 5'10"`}>
                    <input
                      id="height"
                      type="text"
                      placeholder={`5'10"`}
                      className={inputClass(false)}
                      {...register('height')}
                    />
                  </InputField>
                  <InputField id="weight" label="Weight" helper="e.g. 78 kg">
                    <input
                      id="weight"
                      type="text"
                      placeholder="78 kg"
                      className={inputClass(false)}
                      {...register('weight')}
                    />
                  </InputField>
                </div>

                <InputField id="fitnessGoal" label="Fitness Goal" helper="What does this member want to achieve?">
                  <select
                    id="fitnessGoal"
                    className={inputClass(false) + ' appearance-none cursor-pointer'}
                    {...register('fitnessGoal')}
                  >
                    <option value="">Select a goal</option>
                    <option value="Weight loss">Weight loss</option>
                    <option value="Muscle gain">Muscle gain</option>
                    <option value="Muscle toning">Muscle toning</option>
                    <option value="Strength training">Strength training</option>
                    <option value="Cardio & fitness">Cardio &amp; fitness</option>
                    <option value="Flexibility">Flexibility</option>
                    <option value="Overall fitness">Overall fitness</option>
                    <option value="Athletic performance">Athletic performance</option>
                    <option value="Endurance">Endurance</option>
                    <option value="Post-pregnancy fitness">Post-pregnancy fitness</option>
                    <option value="Other">Other</option>
                  </select>
                </InputField>

                <InputField id="medicalNotes" label="Medical Notes" helper="Any injuries, conditions, or restrictions the trainer should know about">
                  <textarea
                    id="medicalNotes"
                    rows={3}
                    placeholder="e.g. Lower back issue, avoid heavy deadlifts. Or leave blank if none."
                    className={inputClass(false) + ' resize-none'}
                    {...register('medicalNotes')}
                  />
                </InputField>

                {/* Summary card */}
                <div className="bg-muted/30 border border-border rounded-xl p-4 space-y-2">
                  <p className="text-xs font-700 text-foreground mb-2">Membership Summary</p>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs">
                    <div className="flex justify-between col-span-2 border-b border-border pb-1.5">
                      <span className="text-muted-foreground">Plan</span>
                      <span className="font-600 text-foreground">{watch('plan') || '—'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Fees</span>
                      <span className="font-600 text-foreground">₹{Number(feesValue).toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Discount</span>
                      <span className="font-600 text-accent">−₹{Number(discountValue).toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Paid</span>
                      <span className="font-600 text-accent">₹{Number(paidValue).toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Pending</span>
                      <span className={`font-700 ${pendingAmount > 0 ? 'text-primary' : 'text-accent'}`}>
                        ₹{pendingAmount.toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </form>

        {/* Footer nav */}
        <div className="shrink-0 border-t border-border px-6 py-4 flex items-center gap-2">
          {step > 0 && (
            <button
              type="button"
              onClick={() => setStep(step - 1)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-border text-sm font-600 text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-150"
            >
              <ChevronLeft size={15} />
              Back
            </button>
          )}
          <div className="flex-1" />
          <button
            type="button"
            onClick={handleClose}
            className="px-4 py-2 rounded-lg text-sm font-600 text-muted-foreground hover:text-foreground transition-colors"
          >
            Cancel
          </button>
          {step < steps.length - 1 ? (
            <button
              type="button"
              onClick={handleNext}
              className="flex items-center gap-1.5 bg-primary hover:bg-primary/90 text-primary-foreground text-sm font-600 px-4 py-2 rounded-lg transition-all duration-150 active:scale-95"
            >
              Next
              <ChevronRight size={15} />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSubmit(onSubmit)}
              disabled={isSubmitting}
              className={`
                flex items-center gap-1.5 bg-accent hover:bg-accent/90 text-white text-sm font-600 px-5 py-2 rounded-lg transition-all duration-150 active:scale-95
                ${isSubmitting ? 'opacity-70 cursor-not-allowed' : ''}
              `}
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Check size={15} />
                  Add Member
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}