'use client';

import React, { useState } from 'react';
import { ArrowUpDown, ArrowUp, ArrowDown, Eye, Pencil, Trash2, RefreshCw } from 'lucide-react';
import StatusBadge from '@/components/ui/StatusBadge';
import { type Member } from './mockData';
import { toast } from 'sonner';
import DeleteConfirmModal from './DeleteConfirmModal';

type SortKey = keyof Pick<Member, 'name' | 'plan' | 'joiningDate' | 'expiryDate' | 'paid' | 'pending' | 'status'>;

interface MemberTableProps {
  members: Member[];
  selectedIds: string[];
  onSelectIds: (ids: string[]) => void;
  onDelete: (id: string) => void;
  totalCount: number;
}

const PAGE_SIZES = [10, 25, 50];

export default function MemberTable({ members, selectedIds, onSelectIds, onDelete, totalCount }: MemberTableProps) {
  const [sortKey, setSortKey] = useState<SortKey>('joiningDate');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [deletingName, setDeletingName] = useState<string>('');

  const sorted = [...members].sort((a, b) => {
    let aVal: string | number = a[sortKey] as string | number;
    let bVal: string | number = b[sortKey] as string | number;
    if (typeof aVal === 'string') aVal = aVal.toLowerCase();
    if (typeof bVal === 'string') bVal = bVal.toLowerCase();
    if (aVal < bVal) return sortDir === 'asc' ? -1 : 1;
    if (aVal > bVal) return sortDir === 'asc' ? 1 : -1;
    return 0;
  });

  const totalPages = Math.max(1, Math.ceil(sorted.length / pageSize));
  const paginated = sorted.slice((page - 1) * pageSize, page * pageSize);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
    setPage(1);
  };

  const SortIcon = ({ col }: { col: SortKey }) => {
    if (sortKey !== col) return <ArrowUpDown size={12} className="text-muted-foreground opacity-50" />;
    return sortDir === 'asc'
      ? <ArrowUp size={12} className="text-primary" />
      : <ArrowDown size={12} className="text-primary" />;
  };

  const allPageSelected = paginated.length > 0 && paginated.every((m) => selectedIds.includes(m.id));
  const someSelected = paginated.some((m) => selectedIds.includes(m.id));

  const toggleAll = () => {
    if (allPageSelected) {
      onSelectIds(selectedIds.filter((id) => !paginated.find((m) => m.id === id)));
    } else {
      const newIds = [...new Set([...selectedIds, ...paginated.map((m) => m.id)])];
      onSelectIds(newIds);
    }
  };

  const toggleRow = (id: string) => {
    if (selectedIds.includes(id)) {
      onSelectIds(selectedIds.filter((sid) => sid !== id));
    } else {
      onSelectIds([...selectedIds, id]);
    }
  };

  const confirmDelete = (member: Member) => {
    setDeletingId(member.id);
    setDeletingName(member.name);
  };

  const handleDeleteConfirm = () => {
    if (!deletingId) return;
    onDelete(deletingId);
    toast.success(`${deletingName} removed from member list`);
    setDeletingId(null);
    setDeletingName('');
  };

  const columns: { key: SortKey | null; label: string; sortable: boolean }[] = [
    { key: null, label: 'Member ID', sortable: false },
    { key: 'name', label: 'Name', sortable: true },
    { key: 'plan', label: 'Plan', sortable: true },
    { key: null, label: 'Trainer', sortable: false },
    { key: 'joiningDate', label: 'Joined', sortable: true },
    { key: 'expiryDate', label: 'Expires', sortable: true },
    { key: 'paid', label: 'Paid (₹)', sortable: true },
    { key: 'pending', label: 'Pending (₹)', sortable: true },
    { key: 'status', label: 'Status', sortable: true },
    { key: null, label: 'Actions', sortable: false },
  ];

  if (members.length === 0) {
    return (
      <div className="bg-card border border-border rounded-xl flex flex-col items-center justify-center py-16 px-4 text-center">
        <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center mb-4">
          <svg className="w-6 h-6 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
        </div>
        <h3 className="text-sm font-700 text-foreground mb-1">No members found</h3>
        <p className="text-xs text-muted-foreground max-w-xs">
          No members match your current search and filters. Try adjusting your criteria or add a new member.
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full min-w-[900px]">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="w-10 px-4 py-3">
                  <input
                    type="checkbox"
                    checked={allPageSelected}
                    ref={(el) => { if (el) el.indeterminate = someSelected && !allPageSelected; }}
                    onChange={toggleAll}
                    className="w-4 h-4 rounded border-border bg-input accent-primary cursor-pointer"
                    aria-label="Select all on this page"
                  />
                </th>
                {columns.map((col, i) => (
                  <th
                    key={`col-${col.label.replace(/\s/g, '-').toLowerCase()}`}
                    className={`px-4 py-3 text-left text-[11px] font-700 uppercase tracking-wider text-muted-foreground whitespace-nowrap ${col.sortable ? 'cursor-pointer hover:text-foreground select-none' : ''}`}
                    onClick={() => col.sortable && col.key && handleSort(col.key as SortKey)}
                  >
                    <div className="flex items-center gap-1.5">
                      {col.label}
                      {col.sortable && col.key && <SortIcon col={col.key as SortKey} />}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {paginated.map((member) => {
                const isSelected = selectedIds.includes(member.id);
                return (
                  <tr
                    key={member.id}
                    className={`
                      group transition-colors duration-100
                      ${isSelected ? 'bg-primary/5' : 'hover:bg-muted/20'}
                    `}
                  >
                    <td className="px-4 py-3">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleRow(member.id)}
                        className="w-4 h-4 rounded border-border bg-input accent-primary cursor-pointer"
                        aria-label={`Select ${member.name}`}
                      />
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs font-600 text-muted-foreground font-mono">{member.memberId}</span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-muted flex items-center justify-center shrink-0">
                          <span className="text-[10px] font-700 text-muted-foreground">
                            {member.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                          </span>
                        </div>
                        <div>
                          <p className="text-sm font-600 text-foreground whitespace-nowrap">{member.name}</p>
                          <p className="text-[11px] text-muted-foreground">{member.phone}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs font-500 text-foreground whitespace-nowrap">{member.plan}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs text-muted-foreground whitespace-nowrap">{member.trainer.split(' ')[0]}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs text-muted-foreground whitespace-nowrap">{member.joiningDate}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs whitespace-nowrap ${
                        member.status === 'expired' ? 'text-primary' :
                        member.status === 'active' && member.expiryDate.includes('/05/2026') ? 'text-yellow-500' :
                        'text-muted-foreground'
                      }`}>{member.expiryDate}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs font-600 text-accent metric-value">₹{member.paid.toLocaleString('en-IN')}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs font-600 metric-value ${member.pending > 0 ? 'text-primary' : 'text-muted-foreground'}`}>
                        {member.pending > 0 ? `₹${member.pending.toLocaleString('en-IN')}` : '—'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={member.status} size="sm" />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-150">
                        <button
                          title="View member profile"
                          className="w-7 h-7 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-150"
                        >
                          <Eye size={14} />
                        </button>
                        <button
                          title="Edit member"
                          className="w-7 h-7 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-150"
                        >
                          <Pencil size={14} />
                        </button>
                        <button
                          title="Renew membership"
                          className="w-7 h-7 flex items-center justify-center rounded-lg text-muted-foreground hover:text-accent hover:bg-accent/10 transition-all duration-150"
                        >
                          <RefreshCw size={14} />
                        </button>
                        <button
                          title="Delete member — this cannot be undone"
                          onClick={() => confirmDelete(member)}
                          className="w-7 h-7 flex items-center justify-center rounded-lg text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all duration-150"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 px-4 py-3 border-t border-border">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span>Rows per page:</span>
            <select
              value={pageSize}
              onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}
              className="bg-input border border-border rounded px-2 py-1 text-foreground text-xs focus:outline-none focus:ring-1 focus:ring-ring"
            >
              {PAGE_SIZES.map((s) => (
                <option key={`page-size-${s}`} value={s} className="bg-card">{s}</option>
              ))}
            </select>
            <span>·</span>
            <span>{Math.min((page - 1) * pageSize + 1, sorted.length)}–{Math.min(page * pageSize, sorted.length)} of {sorted.length}</span>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage(1)}
              disabled={page === 1}
              className="w-7 h-7 flex items-center justify-center rounded text-muted-foreground hover:text-foreground hover:bg-muted disabled:opacity-30 disabled:cursor-not-allowed transition-all duration-150 text-xs font-600"
            >
              «
            </button>
            <button
              onClick={() => setPage(page - 1)}
              disabled={page === 1}
              className="w-7 h-7 flex items-center justify-center rounded text-muted-foreground hover:text-foreground hover:bg-muted disabled:opacity-30 disabled:cursor-not-allowed transition-all duration-150 text-xs"
            >
              ‹
            </button>
            {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
              let pageNum: number;
              if (totalPages <= 5) {
                pageNum = i + 1;
              } else if (page <= 3) {
                pageNum = i + 1;
              } else if (page >= totalPages - 2) {
                pageNum = totalPages - 4 + i;
              } else {
                pageNum = page - 2 + i;
              }
              return (
                <button
                  key={`page-btn-${pageNum}`}
                  onClick={() => setPage(pageNum)}
                  className={`w-7 h-7 flex items-center justify-center rounded text-xs font-600 transition-all duration-150 ${
                    page === pageNum
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  }`}
                >
                  {pageNum}
                </button>
              );
            })}
            <button
              onClick={() => setPage(page + 1)}
              disabled={page === totalPages}
              className="w-7 h-7 flex items-center justify-center rounded text-muted-foreground hover:text-foreground hover:bg-muted disabled:opacity-30 disabled:cursor-not-allowed transition-all duration-150 text-xs"
            >
              ›
            </button>
            <button
              onClick={() => setPage(totalPages)}
              disabled={page === totalPages}
              className="w-7 h-7 flex items-center justify-center rounded text-muted-foreground hover:text-foreground hover:bg-muted disabled:opacity-30 disabled:cursor-not-allowed transition-all duration-150 text-xs font-600"
            >
              »
            </button>
          </div>
        </div>
      </div>

      <DeleteConfirmModal
        open={!!deletingId}
        memberName={deletingName}
        onConfirm={handleDeleteConfirm}
        onClose={() => { setDeletingId(null); setDeletingName(''); }}
      />
    </>
  );
}