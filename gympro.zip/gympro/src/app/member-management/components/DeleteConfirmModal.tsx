'use client';

import React from 'react';
import Modal from '@/components/ui/Modal';
import { AlertTriangle } from 'lucide-react';

interface DeleteConfirmModalProps {
  open: boolean;
  memberName: string;
  onConfirm: () => void;
  onClose: () => void;
}

export default function DeleteConfirmModal({ open, memberName, onConfirm, onClose }: DeleteConfirmModalProps) {
  return (
    <Modal open={open} onClose={onClose} title="Delete Member" size="sm">
      <div className="p-6 space-y-4">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
            <AlertTriangle size={18} className="text-primary" />
          </div>
          <div>
            <p className="text-sm font-600 text-foreground mb-1">Remove {memberName}?</p>
            <p className="text-xs text-muted-foreground leading-relaxed">
              This will permanently delete all records for this member including payment history and attendance logs. This action cannot be undone.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 pt-2">
          <button
            onClick={onClose}
            className="flex-1 py-2 rounded-lg border border-border text-sm font-600 text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-150"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 py-2 rounded-lg bg-primary hover:bg-primary/90 text-primary-foreground text-sm font-600 transition-all duration-150 active:scale-95"
          >
            Delete Member
          </button>
        </div>
      </div>
    </Modal>
  );
}