'use client';

import React from 'react';
import { statuses, plans, trainers } from './mockData';

interface MemberFiltersProps {
  statusFilter: string;
  planFilter: string;
  trainerFilter: string;
  onStatusChange: (v: string) => void;
  onPlanChange: (v: string) => void;
  onTrainerChange: (v: string) => void;
}

const FilterSelect = ({
  label, value, options, onChange,
}: { label: string; value: string; options: string[]; onChange: (v: string) => void }) => (
  <div>
    <label className="block text-[11px] font-600 uppercase tracking-wider text-muted-foreground mb-1.5">{label}</label>
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full bg-input border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all duration-150 appearance-none cursor-pointer"
    >
      {options.map((opt) => (
        <option key={`filter-opt-${opt}`} value={opt} className="bg-card">
          {opt}
        </option>
      ))}
    </select>
  </div>
);

export default function MemberFilters({
  statusFilter, planFilter, trainerFilter,
  onStatusChange, onPlanChange, onTrainerChange,
}: MemberFiltersProps) {
  return (
    <div className="bg-card border border-border rounded-xl p-4 fade-in">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <FilterSelect
          label="Status"
          value={statusFilter}
          options={statuses}
          onChange={onStatusChange}
        />
        <FilterSelect
          label="Membership Plan"
          value={planFilter}
          options={plans}
          onChange={onPlanChange}
        />
        <FilterSelect
          label="Trainer"
          value={trainerFilter}
          options={trainers}
          onChange={onTrainerChange}
        />
      </div>
    </div>
  );
}