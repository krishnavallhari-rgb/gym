export type MemberStatus = 'active' | 'expired' | 'pending' | 'frozen' | 'trial';
export type MembershipPlan = 'Monthly' | 'Quarterly' | 'Half-Yearly' | 'Annual' | 'Personal Training' | 'Trial';

export interface Member {
  id: string;
  memberId: string;
  name: string;
  phone: string;
  email: string;
  gender: 'Male' | 'Female' | 'Other';
  dob: string;
  address: string;
  emergencyContact: string;
  joiningDate: string;
  expiryDate: string;
  plan: MembershipPlan;
  trainer: string;
  fees: number;
  discount: number;
  paid: number;
  pending: number;
  status: MemberStatus;
  height: string;
  weight: string;
  fitnessGoal: string;
  medicalNotes: string;
  checkinsThisMonth: number;
}

export const mockMembers: Member[] = [
  {
    id: 'mem-001', memberId: 'GP-1001', name: 'Arjun Sharma', phone: '98765-43210', email: 'arjun.sharma@gmail.com',
    gender: 'Male', dob: '15/03/1992', address: '42 MG Road, Bengaluru', emergencyContact: '98765-00001',
    joiningDate: '01/06/2025', expiryDate: '17/05/2026', plan: 'Monthly', trainer: 'Suresh Kumar',
    fees: 1800, discount: 0, paid: 1800, pending: 0, status: 'expired',
    height: '5\'10"', weight: '78 kg', fitnessGoal: 'Weight loss', medicalNotes: 'None', checkinsThisMonth: 12,
  },
  {
    id: 'mem-002', memberId: 'GP-1002', name: 'Priya Nair', phone: '87654-32109', email: 'priya.nair@outlook.com',
    gender: 'Female', dob: '22/07/1995', address: '15 Brigade Road, Bengaluru', emergencyContact: '87654-00002',
    joiningDate: '18/02/2026', expiryDate: '18/05/2026', plan: 'Quarterly', trainer: 'Kavita Rao',
    fees: 4500, discount: 200, paid: 4300, pending: 0, status: 'active',
    height: '5\'4"', weight: '58 kg', fitnessGoal: 'Muscle toning', medicalNotes: 'None', checkinsThisMonth: 21,
  },
  {
    id: 'mem-003', memberId: 'GP-1003', name: 'Vikram Patel', phone: '76543-21098', email: 'vikram.patel@gmail.com',
    gender: 'Male', dob: '08/11/1988', address: '7 Residency Road, Bengaluru', emergencyContact: '76543-00003',
    joiningDate: '19/11/2025', expiryDate: '19/05/2026', plan: 'Half-Yearly', trainer: 'Suresh Kumar',
    fees: 8500, discount: 500, paid: 8000, pending: 500, status: 'pending',
    height: '6\'0"', weight: '88 kg', fitnessGoal: 'Strength training', medicalNotes: 'Lower back issue', checkinsThisMonth: 18,
  },
  {
    id: 'mem-004', memberId: 'GP-1004', name: 'Sneha Reddy', phone: '65432-10987', email: 'sneha.reddy@yahoo.com',
    gender: 'Female', dob: '30/01/1997', address: '23 Koramangala, Bengaluru', emergencyContact: '65432-00004',
    joiningDate: '20/11/2025', expiryDate: '20/05/2026', plan: 'Half-Yearly', trainer: 'Kavita Rao',
    fees: 8500, discount: 0, paid: 8500, pending: 0, status: 'active',
    height: '5\'5"', weight: '55 kg', fitnessGoal: 'Flexibility', medicalNotes: 'None', checkinsThisMonth: 24,
  },
  {
    id: 'mem-005', memberId: 'GP-1005', name: 'Karan Mehta', phone: '54321-09876', email: 'karan.mehta@gmail.com',
    gender: 'Male', dob: '14/05/1990', address: '88 Indiranagar, Bengaluru', emergencyContact: '54321-00005',
    joiningDate: '01/05/2026', expiryDate: '31/05/2026', plan: 'Monthly', trainer: 'Rajan Pillai',
    fees: 1800, discount: 0, paid: 900, pending: 900, status: 'pending',
    height: '5\'8"', weight: '72 kg', fitnessGoal: 'Weight loss', medicalNotes: 'None', checkinsThisMonth: 9,
  },
  {
    id: 'mem-006', memberId: 'GP-1006', name: 'Ananya Singh', phone: '43210-98765', email: 'ananya.singh@gmail.com',
    gender: 'Female', dob: '19/09/1993', address: '5 HSR Layout, Bengaluru', emergencyContact: '43210-00006',
    joiningDate: '22/05/2025', expiryDate: '22/05/2026', plan: 'Annual', trainer: 'Kavita Rao',
    fees: 18000, discount: 1000, paid: 17000, pending: 0, status: 'frozen',
    height: '5\'6"', weight: '60 kg', fitnessGoal: 'Overall fitness', medicalNotes: 'Knee surgery recovery', checkinsThisMonth: 0,
  },
  {
    id: 'mem-007', memberId: 'GP-1007', name: 'Rohit Gupta', phone: '32109-87654', email: 'rohit.gupta@hotmail.com',
    gender: 'Male', dob: '03/12/1985', address: '11 JP Nagar, Bengaluru', emergencyContact: '32109-00007',
    joiningDate: '23/05/2025', expiryDate: '23/05/2026', plan: 'Annual', trainer: 'Suresh Kumar',
    fees: 18000, discount: 2000, paid: 16000, pending: 0, status: 'active',
    height: '5\'11"', weight: '82 kg', fitnessGoal: 'Muscle gain', medicalNotes: 'None', checkinsThisMonth: 20,
  },
  {
    id: 'mem-008', memberId: 'GP-1008', name: 'Meera Iyer', phone: '21098-76543', email: 'meera.iyer@gmail.com',
    gender: 'Female', dob: '27/04/1998', address: '34 Whitefield, Bengaluru', emergencyContact: '21098-00008',
    joiningDate: '17/05/2026', expiryDate: '17/06/2026', plan: 'Trial', trainer: 'Rajan Pillai',
    fees: 500, discount: 0, paid: 500, pending: 0, status: 'trial',
    height: '5\'3"', weight: '52 kg', fitnessGoal: 'Cardio & fitness', medicalNotes: 'None', checkinsThisMonth: 1,
  },
  {
    id: 'mem-009', memberId: 'GP-1009', name: 'Aditya Verma', phone: '10987-65432', email: 'aditya.verma@gmail.com',
    gender: 'Male', dob: '11/08/1994', address: '67 Electronic City, Bengaluru', emergencyContact: '10987-00009',
    joiningDate: '01/02/2026', expiryDate: '30/04/2026', plan: 'Quarterly', trainer: 'Suresh Kumar',
    fees: 4500, discount: 0, paid: 4500, pending: 0, status: 'expired',
    height: '5\'9"', weight: '75 kg', fitnessGoal: 'Endurance', medicalNotes: 'Asthma (mild)', checkinsThisMonth: 0,
  },
  {
    id: 'mem-010', memberId: 'GP-1010', name: 'Pooja Krishnamurthy', phone: '09876-54321', email: 'pooja.k@gmail.com',
    gender: 'Female', dob: '06/02/1991', address: '89 Bellandur, Bengaluru', emergencyContact: '09876-00010',
    joiningDate: '01/12/2025', expiryDate: '30/11/2026', plan: 'Annual', trainer: 'Kavita Rao',
    fees: 18000, discount: 1500, paid: 16500, pending: 0, status: 'active',
    height: '5\'4"', weight: '57 kg', fitnessGoal: 'Post-pregnancy fitness', medicalNotes: 'C-section 2024', checkinsThisMonth: 22,
  },
  {
    id: 'mem-011', memberId: 'GP-1011', name: 'Nikhil Joshi', phone: '98765-11223', email: 'nikhil.joshi@gmail.com',
    gender: 'Male', dob: '25/10/1987', address: '12 Marathahalli, Bengaluru', emergencyContact: '98765-00011',
    joiningDate: '01/04/2026', expiryDate: '30/06/2026', plan: 'Quarterly', trainer: 'Rajan Pillai',
    fees: 4500, discount: 0, paid: 3000, pending: 1500, status: 'pending',
    height: '5\'7"', weight: '70 kg', fitnessGoal: 'Fat loss', medicalNotes: 'None', checkinsThisMonth: 14,
  },
  {
    id: 'mem-012', memberId: 'GP-1012', name: 'Divya Menon', phone: '87654-22334', email: 'divya.menon@gmail.com',
    gender: 'Female', dob: '18/06/1996', address: '56 Sarjapur Road, Bengaluru', emergencyContact: '87654-00012',
    joiningDate: '15/03/2026', expiryDate: '14/09/2026', plan: 'Personal Training', trainer: 'Suresh Kumar',
    fees: 12000, discount: 0, paid: 12000, pending: 0, status: 'active',
    height: '5\'5"', weight: '54 kg', fitnessGoal: 'Athletic performance', medicalNotes: 'None', checkinsThisMonth: 26,
  },
];

export const trainers = ['All Trainers', 'Suresh Kumar', 'Kavita Rao', 'Rajan Pillai'];
export const plans: (MembershipPlan | 'All Plans')[] = ['All Plans', 'Monthly', 'Quarterly', 'Half-Yearly', 'Annual', 'Personal Training', 'Trial'];
export const statuses: (MemberStatus | 'All Status')[] = ['All Status', 'active', 'expired', 'pending', 'frozen', 'trial'];