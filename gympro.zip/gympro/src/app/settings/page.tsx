'use client';

import React, { useState } from 'react';
import AppLayout from '@/components/AppLayout';
import { Settings, Building2, Phone, MapPin, Hash, Palette, Bell, Shield, Save, Check, Upload, Globe,  } from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


interface GymSettings {
  gymName: string;
  phone: string;
  address: string;
  gstNumber: string;
  currency: string;
  website: string;
}

interface AppSettings {
  darkMode: boolean;
  emailNotifications: boolean;
  smsAlerts: boolean;
  expiryReminder: number;
  paymentReminder: boolean;
  sessionTimeout: number;
}

const inputClass = 'w-full bg-input border border-border rounded-lg px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all duration-150';
const labelClass = 'block text-xs font-600 text-foreground mb-1.5';

function SectionCard({ title, icon: Icon, children }: { title: string; icon: React.ElementType; children: React.ReactNode }) {
  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="flex items-center gap-2.5 px-5 py-4 border-b border-border">
        <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
          <Icon size={15} className="text-primary" />
        </div>
        <h2 className="text-sm font-700 text-foreground">{title}</h2>
      </div>
      <div className="p-5 space-y-4">{children}</div>
    </div>
  );
}

function Toggle({ checked, onChange, label, description }: { checked: boolean; onChange: (v: boolean) => void; label: string; description?: string }) {
  return (
    <div className="flex items-center justify-between py-2">
      <div>
        <p className="text-sm font-600 text-foreground">{label}</p>
        {description && <p className="text-xs text-muted-foreground mt-0.5">{description}</p>}
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={`relative w-10 h-5.5 rounded-full transition-all duration-200 ${checked ? 'bg-accent' : 'bg-muted border border-border'}`}
        style={{ height: '22px', width: '40px' }}
      >
        <span
          className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all duration-200 ${checked ? 'left-5' : 'left-0.5'}`}
        />
      </button>
    </div>
  );
}

export default function SettingsPage() {
  const [saved, setSaved] = useState(false);
  const [gymSettings, setGymSettings] = useState<GymSettings>({
    gymName: 'GymPro Fitness Center',
    phone: '9876543210',
    address: '42 MG Road, Bengaluru, Karnataka 560001',
    gstNumber: '29ABCDE1234F1Z5',
    currency: 'INR',
    website: 'www.gympro.in',
  });

  const [appSettings, setAppSettings] = useState<AppSettings>({
    darkMode: true,
    emailNotifications: true,
    smsAlerts: false,
    expiryReminder: 7,
    paymentReminder: true,
    sessionTimeout: 30,
  });

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const updateGym = (key: keyof GymSettings, value: string) =>
    setGymSettings((prev) => ({ ...prev, [key]: value }));

  const updateApp = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) =>
    setAppSettings((prev) => ({ ...prev, [key]: value }));

  return (
    <AppLayout>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-sm border-b border-border px-6 py-4">
          <div className="max-w-screen-lg mx-auto flex items-center justify-between">
            <div>
              <h1 className="text-xl font-700 text-foreground">Settings</h1>
              <p className="text-xs text-muted-foreground mt-0.5">Manage gym profile and app preferences</p>
            </div>
            <button
              onClick={handleSave}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-600 transition-all duration-200 active:scale-95 ${
                saved
                  ? 'bg-accent/15 text-accent border border-accent/25' :'bg-primary hover:bg-primary/90 text-white'
              }`}
            >
              {saved ? <><Check size={14} /> Saved!</> : <><Save size={14} /> Save Changes</>}
            </button>
          </div>
        </div>

        <div className="max-w-screen-lg mx-auto px-6 py-6 space-y-6">
          {/* Gym Settings */}
          <SectionCard title="Gym Profile" icon={Building2}>
            {/* Logo upload */}
            <div className="flex items-center gap-4 pb-4 border-b border-border">
              <div className="w-16 h-16 rounded-xl bg-primary/10 border-2 border-dashed border-primary/30 flex items-center justify-center">
                <span className="text-xl font-800 text-primary">GP</span>
              </div>
              <div>
                <p className="text-sm font-600 text-foreground">Gym Logo</p>
                <p className="text-xs text-muted-foreground mb-2">PNG, JPG up to 2MB</p>
                <button className="flex items-center gap-1.5 text-xs font-600 text-muted-foreground hover:text-foreground bg-muted border border-border px-3 py-1.5 rounded-lg transition-all duration-150">
                  <Upload size={12} />
                  Upload Logo
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Gym Name</label>
                <div className="relative">
                  <Building2 size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input
                    type="text"
                    value={gymSettings.gymName}
                    onChange={(e) => updateGym('gymName', e.target.value)}
                    className={inputClass + ' pl-9'}
                  />
                </div>
              </div>
              <div>
                <label className={labelClass}>Contact Number</label>
                <div className="relative">
                  <Phone size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input
                    type="tel"
                    value={gymSettings.phone}
                    maxLength={10}
                    onChange={(e) => {
                      const val = e.target.value.replace(/\D/g, '').slice(0, 10);
                      updateGym('phone', val);
                    }}
                    className={inputClass + ' pl-9'}
                    placeholder="10-digit number"
                  />
                </div>
              </div>
              <div className="sm:col-span-2">
                <label className={labelClass}>Address</label>
                <div className="relative">
                  <MapPin size={14} className="absolute left-3 top-3 text-muted-foreground" />
                  <textarea
                    rows={2}
                    value={gymSettings.address}
                    onChange={(e) => updateGym('address', e.target.value)}
                    className={inputClass + ' pl-9 resize-none'}
                  />
                </div>
              </div>
              <div>
                <label className={labelClass}>GST Number</label>
                <div className="relative">
                  <Hash size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input
                    type="text"
                    value={gymSettings.gstNumber}
                    onChange={(e) => updateGym('gstNumber', e.target.value)}
                    className={inputClass + ' pl-9'}
                    placeholder="29ABCDE1234F1Z5"
                  />
                </div>
              </div>
              <div>
                <label className={labelClass}>Website</label>
                <div className="relative">
                  <Globe size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input
                    type="text"
                    value={gymSettings.website}
                    onChange={(e) => updateGym('website', e.target.value)}
                    className={inputClass + ' pl-9'}
                    placeholder="www.yourgym.com"
                  />
                </div>
              </div>
            </div>
          </SectionCard>

          {/* App Settings */}
          <SectionCard title="App Preferences" icon={Palette}>
            <Toggle
              checked={appSettings.darkMode}
              onChange={(v) => updateApp('darkMode', v)}
              label="Dark Mode"
              description="Use dark theme across the application"
            />
            <div className="border-t border-border" />
            <div>
              <label className={labelClass}>Currency</label>
              <select
                value={gymSettings.currency}
                onChange={(e) => updateGym('currency', e.target.value)}
                className={inputClass + ' appearance-none cursor-pointer'}
              >
                <option value="INR">₹ Indian Rupee (INR)</option>
                <option value="USD">$ US Dollar (USD)</option>
                <option value="EUR">€ Euro (EUR)</option>
              </select>
            </div>
          </SectionCard>

          {/* Notification Settings */}
          <SectionCard title="Notification Settings" icon={Bell}>
            <Toggle
              checked={appSettings.emailNotifications}
              onChange={(v) => updateApp('emailNotifications', v)}
              label="Email Notifications"
              description="Receive alerts via email"
            />
            <div className="border-t border-border" />
            <Toggle
              checked={appSettings.smsAlerts}
              onChange={(v) => updateApp('smsAlerts', v)}
              label="SMS Alerts"
              description="Send SMS reminders to members"
            />
            <div className="border-t border-border" />
            <Toggle
              checked={appSettings.paymentReminder}
              onChange={(v) => updateApp('paymentReminder', v)}
              label="Payment Due Reminders"
              description="Alert when members have pending payments"
            />
            <div className="border-t border-border" />
            <div>
              <label className={labelClass}>Expiry Reminder (days before)</label>
              <select
                value={appSettings.expiryReminder}
                onChange={(e) => updateApp('expiryReminder', Number(e.target.value))}
                className={inputClass + ' appearance-none cursor-pointer'}
              >
                {[3, 5, 7, 10, 14, 30].map((d) => (
                  <option key={d} value={d}>{d} days before expiry</option>
                ))}
              </select>
            </div>
          </SectionCard>

          {/* Security Settings */}
          <SectionCard title="Security" icon={Shield}>
            <div>
              <label className={labelClass}>Session Timeout (minutes)</label>
              <select
                value={appSettings.sessionTimeout}
                onChange={(e) => updateApp('sessionTimeout', Number(e.target.value))}
                className={inputClass + ' appearance-none cursor-pointer'}
              >
                {[15, 30, 60, 120, 240].map((m) => (
                  <option key={m} value={m}>{m} minutes</option>
                ))}
              </select>
            </div>
            <div className="border-t border-border pt-4">
              <p className="text-sm font-600 text-foreground mb-1">Change Password</p>
              <p className="text-xs text-muted-foreground mb-3">Update your admin account password</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input type="password" placeholder="Current password" className={inputClass} />
                <input type="password" placeholder="New password" className={inputClass} />
              </div>
            </div>
          </SectionCard>
        </div>
      </div>
    </AppLayout>
  );
}
